/**
 * @file stage2_strategy.cpp
 * @brief 第二阶段基础决策：收益/路程选目标，局部攻防选动作，逐帧重规划。
 *
 * BFS一次计算已知可通行格的真实步数，A*生成最终路线。资源、任务、探索、
 * 有利交战共用一个收益尺度；射程内攻击无视障碍，但移动仍遵守地形与占位。
 * 所有对手下一步行为都是估计：日志分别给出预计收益和可能受到的伤害上界。
 */
#include "rmtc_connection/stage2_strategy.hpp"
#include "rmtc_connection/stage2_event_escape.hpp"
#include "rmtc_connection/stage2_rollout.hpp"
#include "rmtc_connection/stage2_frontier_value.hpp"
#include "rmtc_connection/stage2_event_route.hpp"
#include "rmtc_connection/stage2_resource_lookahead.hpp"
#include "rmtc_connection/stage2_enemy_sightings.hpp"
#include "rmtc_connection/stage2_tactical_navigation.hpp"
#include "rmtc_connection/stage2_observation_age.hpp"
#include "rmtc_connection/stage2_collection.hpp"
#include "rmtc_connection/stage2_collection_search.hpp"
#include "rmtc_connection/stage2_exploration_value.hpp"
#include "rmtc_connection/stage2_resource_sweep.hpp"
#include "rmtc_connection/stage2_opponent_motion.hpp"
#include "rmtc_connection/stage2_opponent_intent.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <queue>
#include <set>
#include <stdexcept>
#include <utility>

namespace rmtc {
namespace {

constexpr std::array<Position, 4> kSteps{{{0, -1}, {0, 1}, {-1, 0}, {1, 0}}};
constexpr std::array<const char*, 4> kDirections{{"up", "down", "left", "right"}};

/// 比较绝对坐标；不将坐标近似或历史敌人位置当成当前相同格。
bool same(Position a, Position b) {
  return a.x == b.x && a.y == b.y;
}

/// 四方向网格的曼哈顿距离，仅用于射程和风险估计；寻路步数另由BFS/A*给出。
int distance(Position a, Position b) {
  return std::abs(a.x - b.x) + std::abs(a.y - b.y);
}

/// 判断标准攻击的直线两格射程，故意不检查障碍遮挡。
bool in_range(Position from, Position to) {
  return (from.x == to.x || from.y == to.y) && distance(from, to) > 0 && distance(from, to) <= 2;
}

/// 将世界坐标映射到便于BFS使用的上到下数组；与MapMemory的底到顶数组区分。
int cell(Position p, MapSize map) {
  return p.y * map.width + p.x;
}

/// 检查地图坐标合法性，防止事件解释或任务坐标导致越界。
bool inside(Position p, MapSize map) {
  return p.x >= 0 && p.y >= 0 && p.x < map.width && p.y < map.height;
}

/**
 * @brief 收到真实移动冲突后按席位错峰重试，打破两车同等时长等待后再次相撞的同步。
 * base为配置的基础避让Tick，0严格关闭；A/B/C/D分别附加0/1/2/3 Tick。
 * 未知席位只使用base。这里只计算临时避让期限，不把空格改成永久障碍。
 */
int collision_retry_delay(const std::string& team, int base) {
  if (base <= 0)
    return 0;
  const int offset = team.size() == 1 && team[0] >= 'A' && team[0] <= 'D'
                         ? team[0] - 'A'
                         : 0;
  return base + offset;
}

/// 将资源/伤害增量换算为尚未饱和的真实比赛分数，不累计超过上限的虚假收益。
double marginal(double current, double increment, double cap, double points) {
  return points / cap * std::max(0.0, std::min(increment, cap - current));
}

/// 当前可见活敌车；历史记忆不会进入本列表，也不会造成永久占位。
std::vector<const VisibleEntity*> enemies(const PublicPerception& frame) {
  std::vector<const VisibleEntity*> result;
  for (const auto& entity : frame.visible_entities) {
    if (entity.type == "robot" && entity.team != frame.self.team && (!entity.hp || *entity.hp > 0))
      result.push_back(&entity);
  }
  return result;
}

/// 每个方向只命中最近机器人；最近目标受保护时，不能越过它攻击第二辆车。
const VisibleEntity* attack_target(Position from, Position step,
                                   const std::vector<const VisibleEntity*>& visible) {
  const VisibleEntity* nearest = nullptr;
  int best = 3;
  for (const auto* enemy : visible) {
    const auto p = enemy->position;
    const int d = distance(from, p);
    if (d >= 1 && d < best && p.x == from.x + step.x * d && p.y == from.y + step.y * d) {
      nearest = enemy;
      best = d;
    }
  }
  return nearest;
}

/// 将一次总有效伤害估计换算成边际分数；范围攻击合计后封顶，避免多目标重复满分。
double damage_gain(const PublicPerception& frame, const Stage2Weights& weights, double damage) {
  double points =
      marginal(frame.score.effective_damage, damage, weights.damage_cap, weights.damage_points);
  for (const auto& mission : frame.missions) {
    if (mission.type != "effective_damage" || !mission.target || *mission.target <= 0 ||
        std::find(frame.score.mission_completed_ids.begin(),
                  frame.score.mission_completed_ids.end(),
                  mission.id) != frame.score.mission_completed_ids.end())
      continue;
    const double left = *mission.target - frame.score.effective_damage;
    if (left > 0)
      points += weights.mission_points * weights.mission_potential * std::min(1.0, damage / left);
  }
  return points;
}

/// 事件缺省时保留原普通攻击估计；不把上一帧defending当成本Tick确定动作。
double attack_gain(const VisibleEntity& enemy, const PublicPerception& frame,
                   const Stage2Weights& weights) {
  if (enemy.spawn_protected.value_or(false))
    return 0;
  double damage = weights.attack_damage_estimate;
  if (enemy.hp)
    damage = std::min(damage, *enemy.hp);
  if (enemy.hp && *enemy.hp <= 10)
    damage += weights.kill_reward_estimate;
  return damage_gain(frame, weights, damage);
}

/// 一项候选目标；utility越大越优，字段保留收益分解以便调参定位原因。
struct Candidate {
  std::string kind, id;
  Position position;
  double resource{0}, mission{0}, combat{0}, information{0}, utility{0}, patrol{0}, safety{0};
  double event_reward{0};
  double age_information{0};
  bool joint{false};
  bool visible_resource{false};
  double reach_priority{-1};
  double future_utility{0};
  bool sweep{false};
  bool collection_search{false};
  bool resource_race{false};
  double planned_utility{0};
  double switch_bonus{0}; ///< 保持原目标的选择奖励，不是移动一步实际获得的分数。
};

}  // namespace

Stage2Strategy::Stage2Strategy(Stage2Weights weights) : weights_(weights) {
  weights_.purpose.validate();
  weights_.acquisition.validate();
  weights_.temporal.validate();
  const auto& race = weights.resource_race;
  if (race.target_limit < 1 || race.target_limit > 16 || race.horizon < 1 || race.horizon > 500 ||
      race.deadline_slack < 0 || race.deadline_slack > 100 || race.explore_ticks < 0 ||
      race.explore_ticks > 500 || !std::isfinite(race.distance_cost) || race.distance_cost < 0 ||
      !std::isfinite(race.move_priority) || race.move_priority < 0 || race.move_priority > 10 ||
      !std::isfinite(race.budget_ms) || race.budget_ms < 1 || race.budget_ms > 150 ||
      !std::isfinite(race.coverage_offset) || race.coverage_offset < 0)
    throw std::invalid_argument("resource race limits/weights outside bounds");
  for (double v : {race.explore_offset, race.explore_distance_power, race.explore_edge_bonus,
      race.explore_competition, race.explore_urgency, race.explore_race_scale,
      race.explore_capture_floor, race.explore_move_priority, race.terminal_information,
      race.mission_weight})
    if (!std::isfinite(v) || v < 0) throw std::invalid_argument("invalid resource race feature weights");
  if (race.explore_method < 0 || race.explore_method > 1 || race.explore_distance_power <= 0 ||
      race.explore_race_scale <= 0 || race.explore_competition > 1 ||
      race.explore_capture_floor > 1 || race.task_deadline_buffer < 0 || race.task_deadline_buffer > 100)
    throw std::invalid_argument("invalid resource race feature bounds");
  weights_.phase.validate();
  weights_.events.validate();
  weights_.rollout.validate();
  weights_.interference.validate();
  for(double value:{weights.combat_clue_weight,weights.combat_clue_half_life,
      weights.opening_depletion_weight,weights.opening_depletion_floor,weights.opening_depletion_half_life})
    if(!std::isfinite(value)||value<0) throw std::invalid_argument("invalid battle evidence weights");
  if(weights.combat_clue_weight>2||weights.combat_clue_half_life<=0||weights.combat_clue_max_age<1||
     weights.combat_clue_max_age>60||weights.third_party_memory_ticks<0||weights.third_party_memory_ticks>8||
     weights.opening_depletion_weight>2||weights.opening_depletion_floor<.2||weights.opening_depletion_floor>1||
     weights.opening_depletion_half_life<=0||weights.opening_depletion_ticks<0||weights.opening_depletion_ticks>500)
    throw std::invalid_argument("battle evidence window outside bounds");
  for(double value:{weights.collection_search_weight,weights.collection_search_future,
      weights.collection_search_discount,weights.collection_search_risk,weights.collection_search_budget_ms})
    if(!std::isfinite(value)||value<0) throw std::invalid_argument("invalid collection search weights");
  if(weights.collection_search_weight>3||weights.collection_search_future>2||
     weights.collection_search_discount>1||weights.collection_search_budget_ms<1||
     weights.collection_search_budget_ms>150||weights.collection_search_ticks<0||
     weights.collection_search_ticks>500||weights.collection_search_horizon<1||
     weights.collection_search_horizon>100||weights.collection_search_depth<1||
     weights.collection_search_depth>8||weights.collection_search_beam<4||
     weights.collection_search_beam>256||weights.collection_search_targets<4||
     weights.collection_search_targets>32||weights.collection_search_resources<1||
     weights.collection_search_resources>16)
    throw std::invalid_argument("collection search budget outside bounds");
  if (!std::isfinite(weights.frontier_resource_weight) || weights.frontier_resource_weight < 0 ||
      !std::isfinite(weights.frontier_mission_weight) || weights.frontier_mission_weight < 0 ||
      !std::isfinite(weights.frontier_resource_half_life) ||
      weights.frontier_resource_half_life <= 0)
    throw std::invalid_argument("invalid frontier opportunity weights");
  if (weights.resource_mission_ramp_ticks < 0 || weights.resource_mission_ramp_ticks > 500)
    throw std::invalid_argument("resource mission ramp outside bounds");
  const std::array<double, 99> numbers{{static_cast<double>(weights.navigation_cycle_start_tick),
                                        weights.navigation_cycle_cost,
                                        static_cast<double>(weights.navigation_cycle_window),
                                        static_cast<double>(weights.navigation_cycle_cooldown),
                                        weights.sweep_weight,weights.sweep_discount,
                                        static_cast<double>(weights.sweep_ticks),
                                        static_cast<double>(weights.sweep_horizon),
                                        static_cast<double>(weights.sweep_beam),
                                        weights.information_softness,
                                        weights.recent_enemy_search_weight,
                                        weights.recent_enemy_half_life,
                                        static_cast<double>(weights.recent_enemy_max_age),
                                        static_cast<double>(weights.blocked_retry_ticks),
                                        weights.resource_lookahead_weight,
                                        static_cast<double>(weights.resource_lookahead_steps),
                                        static_cast<double>(weights.resource_lookahead_limit),
                                        static_cast<double>(weights.resource_lookahead_depth),
                                        weights.route_information_weight,
                                        weights.reach_weight_end,
                                        static_cast<double>(weights.reach_ramp_ticks),
                                        static_cast<double>(weights.reach_deadline_buffer),
                                        weights.reach_deadline_weight,
                                        weights.visible_resource_weight,
                                        weights.resource_mission_weight,
                                        weights.resource_mission_weight_end,
                                        static_cast<double>(weights.resource_mission_ramp_ticks),
                                        static_cast<double>(weights.observation_start_tick),
                                        static_cast<double>(weights.observation_ramp_ticks),
                                        weights.observation_age_weight,
                                        static_cast<double>(weights.observation_fresh_ticks),
                                        static_cast<double>(weights.observation_stale_ticks),
                                        weights.route_alternatives_weight,
                                        weights.resource_cap,
                                        weights.resource_points,
                                        weights.damage_cap,
                                        weights.damage_points,
                                        weights.mission_points,
                                        weights.mission_potential,
                                        weights.travel_offset,
                                        weights.information_per_cell,
                                        weights.information_cap,
                                        weights.edge_information_bonus,
                                        weights.resource_age_ticks,
                                        weights.contested_resource_factor,
                                        weights.remembered_risk,
                                        weights.route_risk,
                                        weights.switch_margin,
                                        weights.attack_damage_estimate,
                                        weights.attack_probability,
                                        weights.hp_loss_cost,
                                        weights.death_cost,
                                        weights.future_exposure_cost,
                                        weights.kill_reward_estimate,
                                        static_cast<double>(weights.enemy_memory_ticks),
                                        weights.patrol_value,
                                        weights.patrol_stale_ticks,
                                        static_cast<double>(weights.patrol_min_age),
                                        weights.patrol_enemy_hint,
                                        static_cast<double>(weights.opening_ticks),
                                        weights.opening_resource_weight,
                                        weights.opening_combat_weight,
                                        weights.combat_weight_end,
                                        static_cast<double>(weights.combat_ramp_ticks),
                                        weights.opening_reach_weight,
                                        weights.initial_resource_value,
                                        weights.resource_need_power,
                                        weights.resource_coverage_power,
                                        weights.resource_depletion_power,
                                        weights.exploration_floor,
                                        weights.collection_mission_weight,
                                        static_cast<double>(weights.chase_stall_ticks),
                                        static_cast<double>(weights.chase_cooldown_ticks),
                                        static_cast<double>(weights.collection_mode),
                                        static_cast<double>(weights.joint_ticks),
                                        static_cast<double>(weights.joint_resource_limit),
                                        static_cast<double>(weights.joint_horizon),
                                        weights.joint_future_weight,
                                        weights.joint_observation_offset,
                                        weights.joint_unknown_weight,
                                        static_cast<double>(weights.joint_min_resources),
                                        weights.joint_future_weight_end,
                                        weights.joint_observation_offset_end,
                                        weights.competition_softness,
                                        weights.competition_weight,
                                        weights.competition_weight_end,
                                        weights.resource_weight_end,
                                        weights.opponent_motion_weight,
                                        weights.endgame_preserve_weight,
                                        weights.low_hp_risk_weight,
                                        weights.retreat_damage_fraction,
                                        static_cast<double>(weights.retreat_buffer_ticks),
                                        static_cast<double>(weights.retreat_window_ticks),
                                        weights.intent_chase_weight,
                                        weights.intent_risk_weight,
                                        weights.third_party_risk_discount,
                                        weights.third_party_attack_bonus,
                                        weights.intent_heading_weight,
                                        static_cast<double>(weights.intent_memory_ticks)}};
  for (double value : numbers) {
    if (!std::isfinite(value) || value < 0)
      throw std::invalid_argument("stage2 weights must be finite and nonnegative");
  }
  if (weights.blocked_retry_min_failures < 1 || weights.blocked_retry_min_failures > 32 ||
      weights.recent_enemy_half_life <= 0 || weights.recent_enemy_max_age < 1 ||
      weights.recent_enemy_max_age > 60 || weights.blocked_retry_ticks > 8 ||
      weights.resource_lookahead_steps < 1 || weights.resource_lookahead_limit < 2 ||
      weights.resource_lookahead_limit > 10 || weights.resource_lookahead_depth < 2 ||
      weights.resource_lookahead_depth > 3 || weights.route_information_weight > 1 ||
      weights.resource_cap <= 0 || weights.damage_cap <= 0 || weights.travel_offset <= 0 ||
      weights.resource_age_ticks <= 0 || weights.mission_potential > 1 ||
      weights.information_softness > 1 ||
      weights.sweep_discount > 1 || weights.sweep_ticks > 500 ||
      weights.sweep_horizon < 1 || weights.sweep_horizon > 24 ||
      weights.sweep_beam < 4 || weights.sweep_beam > 64 ||
      (weights.navigation_cycle_window>0&&weights.navigation_cycle_window<8)||
      weights.navigation_cycle_window>40||weights.navigation_cycle_cooldown<1||
      weights.navigation_cycle_start_tick>500||
      weights.navigation_cycle_cooldown>100||
      weights.contested_resource_factor > 1 || weights.attack_probability > 1 ||
      weights.attack_damage_estimate < 10 || weights.attack_damage_estimate > 20 ||
      weights.patrol_stale_ticks <= 0 || weights.initial_resource_value <= 0 ||
      weights.observation_stale_ticks <= weights.observation_fresh_ticks ||
      weights.route_alternatives_weight > 1 || weights.intent_chase_weight > 1 ||
      weights.intent_risk_weight > 1 || weights.third_party_risk_discount > 1 ||
      weights.third_party_attack_bonus > 1 || weights.intent_memory_ticks > 3 ||
      weights.opponent_motion_weight > 1 || weights.retreat_damage_fraction > 1 ||
      weights.retreat_window_ticks < 1 || weights.exploration_floor > 1 ||
      weights.collection_mode > 2 || weights.joint_min_resources > weights.joint_resource_limit ||
      weights.joint_resource_limit < 1 || weights.joint_resource_limit > 10 ||
      weights.competition_softness <= 0 || weights.competition_weight > 1 ||
      weights.competition_weight_end > 1 || weights.joint_horizon < 1 ||
      weights.chase_cooldown_ticks <= 0 ||
      (weights.chase_stall_ticks > 0 && weights.chase_stall_ticks < 8))
    throw std::invalid_argument("stage2 caps/offsets/probabilities/damage outside valid range");
}

void Stage2Strategy::reset() {
  battle_evidence_.reset();
  enemy_beliefs_.reset();
  navigation_progress_.reset();
  events_.reset();
  physical_cached_ = Action::wait();
  blocked_retry_until_.clear();
  blocked_retry_target_.reset();
  blocked_retry_streak_ = 0;
  phase_last_resource_tick_ = 0;
  acquisition_last_activity_tick_ = 0;
  memory_ = MapMemory{};
  joint_planner_.reset();
  race_coverage_planner_.reset();
  plan_ = Stage2Plan{};
  previous_.reset();
  intent_previous_.reset();
  event_.reset();
  normal_collected_ = high_collected_ = 0;
  previous_goal_.clear();
  pursuit_target_.clear();
  pursuit_positions_.clear();
  pursuit_targets_.clear();
  pursuit_cooldown_.clear();
  unproductive_pursuit_.clear();
  last_observed_tick_.clear();
  cached_ = Action::wait();
}

const Stage2Plan& Stage2Strategy::plan() const noexcept {
  return plan_;
}

bool Stage2Strategy::set_event_constraints(const Stage2EventConstraints& constraints) {
  if (!memory_.current())
    return false;
  const auto& frame = *memory_.current();
  if (constraints.session_id != frame.session_id || constraints.source_text.empty() ||
      (constraints.source_text != frame.event_text &&
       frame.event_text.compare(0, constraints.source_text.size(), constraints.source_text) != 0) ||
      constraints.source_tick < 0 || constraints.source_tick > frame.tick ||
      constraints.begin_tick < 0 || constraints.end_tick <= constraints.begin_tick ||
      constraints.end_tick <= frame.tick ||
      (event_ && constraints.source_tick < event_->source_tick))
    return false;
  for (auto p : constraints.dangerous_cells) {
    if (!inside(p, frame.map))
      return false;
  }
  for (const auto& effect : constraints.events) {
    if (effect.begin_tick < 0 || effect.end_tick <= effect.begin_tick)
      return false;
    for (auto p : effect.cells)
      if (!inside(p, frame.map))
        return false;
    for (auto p : effect.points)
      if (!inside(p, frame.map))
        return false;
  }
  if (constraints.timeline)
    events_.merge(constraints, frame, memory_);
  event_ = constraints;
  return true;
}

Action Stage2Strategy::decide(const PublicPerception& frame, std::int64_t remaining_ticks,
                              const Stage2EventConstraints* incoming_event) {
  const auto active_weights=temporal_weights_at(weights_,frame.tick);
  if (memory_.current() && frame.session_id == memory_.current()->session_id &&
      frame.tick == memory_.current()->tick)
    return remaining_ticks > 0 ? cached_ : Action::wait();
  const auto old = memory_.current();
  if (!memory_.update(frame))
    return Action::wait();
  if (!old || old->session_id != frame.session_id) {
    battle_evidence_.reset();
    enemy_beliefs_.reset();
    navigation_progress_.reset();
    events_.reset();
    physical_cached_ = Action::wait();
    joint_planner_.reset();
    race_coverage_planner_.reset();
    previous_.reset();
    intent_previous_.reset();
    event_.reset();
    normal_collected_ = high_collected_ = 0;
    phase_last_resource_tick_ = 0;
    acquisition_last_activity_tick_ = 0;
    previous_goal_.clear();
    pursuit_target_.clear();
    pursuit_positions_.clear();
    pursuit_targets_.clear();
    pursuit_cooldown_.clear();
    unproductive_pursuit_.clear();
    last_observed_tick_.assign(memory_.cells().size(), -1);
    blocked_retry_until_.clear();
  }
  // 仅接受连续帧中、与本程序上一条MOVE对应的真实E_BLOCKED回执；复活/漏帧不猜冲突。
  for (auto it = blocked_retry_until_.begin(); it != blocked_retry_until_.end();) {
    if (it->second <= frame.tick)
      it = blocked_retry_until_.erase(it);
    else
      ++it;
  }
  bool received_collision = false;
  if (active_weights.blocked_retry_ticks > 0 && old && old->session_id == frame.session_id &&
      frame.tick == old->tick + 1 && old->self.alive && frame.self.alive &&
      frame.self.position_reason != "respawn" && same(old->self.position, frame.self.position) &&
      cached_.type == "move" && frame.self.last_action &&
      frame.self.last_action->tick == old->tick && frame.self.last_action->action == "move" &&
      !frame.self.last_action->moved && frame.self.last_action->error == "E_BLOCKED") {
    for (std::size_t i = 0; i < kDirections.size(); ++i) {
      if (physical_cached_.direction == kDirections[i]) {
        const Position failed{old->self.position.x + kSteps[i].x,
                              old->self.position.y + kSteps[i].y};
        if (inside(failed, frame.map)) {
          received_collision = true;
          blocked_retry_streak_ = blocked_retry_target_ && same(*blocked_retry_target_, failed)
                                      ? std::min(blocked_retry_streak_ + 1,
                                                 active_weights.blocked_retry_min_failures)
                                      : 1;
          blocked_retry_target_ = failed;
          // 短暂的同时抢格通常下一两Tick就能通过；只对持续相同的真实失败暂时绕行。
          if (blocked_retry_streak_ >= active_weights.blocked_retry_min_failures)
            blocked_retry_until_[{failed.x, failed.y}] =
                frame.tick + collision_retry_delay(frame.self.team, active_weights.blocked_retry_ticks);
        }
        break;
      }
    }
  }
  if (!received_collision) {
    blocked_retry_target_.reset();
    blocked_retry_streak_ = 0;
  }
  if (old && old->event_text != frame.event_text && event_ && !event_->timeline &&
      frame.event_text.compare(0, old->event_text.size(), old->event_text) != 0)
    event_.reset();  // 公告改变后不让旧结构解释因相同文本再次出现而复活。
  // 只在连续两帧、上一帧资源仍可见、本人实际到达且资源分数相应增长时计数。
  // 这是一份保守下界：漏帧或中途接入时不凭总分拆猜普通/高价值数量。
  if (previous_ && frame.tick == previous_->tick + 1 && previous_->self.alive && frame.self.alive) {
    const double delta = frame.score.resource_value - previous_->score.resource_value;
    for (const auto& entity : previous_->visible_entities) {
      if ((entity.type == "resource_normal" || entity.type == "resource_high") &&
          same(entity.position, frame.self.position) && entity.value &&
          std::abs(delta - *entity.value) < 1e-6) {
        if (entity.type == "resource_high")
          ++high_collected_;
        else
          ++normal_collected_;
        break;
      }
    }
  }
  // 追击必须兑现伤害；即使一直跑到新格子，也不能无限跟在同一敌人身后。
  if(active_weights.purpose.enabled&&old&&old->session_id==frame.session_id&&
      frame.tick==old->tick+1&&old->self.alive&&frame.self.alive) {
    if(frame.score.effective_damage>old->score.effective_damage)unproductive_pursuit_.clear();
    else if(plan_.goal=="combat"&&cached_.type=="move") {
      auto& spent=unproductive_pursuit_[plan_.target_id];
      if(++spent>=active_weights.purpose.chase_progress_ticks) {
        pursuit_cooldown_[plan_.target_id]=frame.tick+active_weights.chase_cooldown_ticks;
        spent=0;
      }
    }
  } else if(active_weights.purpose.enabled)unproductive_pursuit_.clear();
  // 只识别真实连续帧中的局部循环；长途追击经过新格子、已有伤害进展或中途漏帧均不触发。
  // 暂停的是追击目标收益，当前射程内的合法攻击与防御候选仍照常参与比较。
  for (auto it = pursuit_cooldown_.begin(); it != pursuit_cooldown_.end();) {
    if (it->second <= frame.tick)
      it = pursuit_cooldown_.erase(it);
    else
      ++it;
  }
  if (active_weights.chase_stall_ticks > 0 && old && old->session_id == frame.session_id &&
      frame.tick == old->tick + 1 && old->self.alive && frame.self.alive &&
      plan_.goal == "combat" && cached_.type == "move" &&
      frame.score.effective_damage <= old->score.effective_damage) {
    if (!active_weights.chase_shared_progress && pursuit_target_ != plan_.target_id) {
      pursuit_target_ = plan_.target_id;
      pursuit_positions_.clear();
      pursuit_targets_.clear();
    }
    pursuit_positions_.push_back(frame.self.position);
    pursuit_targets_.push_back(plan_.target_id);
    while (pursuit_positions_.size() > static_cast<std::size_t>(active_weights.chase_stall_ticks)) {
      pursuit_positions_.pop_front();
      pursuit_targets_.pop_front();
    }
    if (pursuit_positions_.size() == static_cast<std::size_t>(active_weights.chase_stall_ticks)) {
      std::set<std::pair<int, int>> visited;
      for (const auto p : pursuit_positions_)
        visited.emplace(p.x, p.y);
      if (visited.size() <= 4) {
        for (const auto& target : pursuit_targets_)
          pursuit_cooldown_[target] = frame.tick + active_weights.chase_cooldown_ticks;
        pursuit_positions_.clear();
        pursuit_targets_.clear();
      }
    }
  } else {
    pursuit_positions_.clear();
    pursuit_targets_.clear();
    pursuit_target_.clear();
  }
  previous_ = frame;
  plan_ = Stage2Plan{};
  plan_.blocked_retry_streak = blocked_retry_streak_;
  for (const auto& [position, until] : blocked_retry_until_)
    plan_.blocked_retries.push_back(
        {{"position", {position.first, position.second}}, {"until_tick", until}});
  plan_.pursuit_cooldowns = pursuit_cooldown_.size();
  cached_ = Action::wait();
  events_.observe(frame, memory_);
  if (incoming_event)
    set_event_constraints(*incoming_event);  // 先接受当前感知，再校验异步结果，避免额外晚一Tick。
  const bool matching_event = event_ && event_->source_text == frame.event_text;
  plan_.event_state = events_.describe(frame);
  plan_.event_pending = !frame.event_text.empty() && !matching_event;
  if (remaining_ticks <= 0 || !frame.self.alive) {
    plan_.goal = frame.self.alive ? "finished" : "respawn_wait";
    return cached_;
  }

  const auto visible = enemies(frame);
  if(active_weights.combat_clue_weight>0||active_weights.opening_depletion_weight>0)
    battle_evidence_.update(frame,old,events_,physical_cached_,memory_,active_weights);
  plan_.battle_evidence=battle_evidence_.details;
  plan_.resource_origins=battle_evidence_.origins;
  const auto own_unrivaled = events_.buff(frame.self.team, "unrivaled", frame.tick);
  const auto purity = events_.active("purity", frame.tick);
  const auto multiplier = [&](const std::string& team) {
    const auto state = events_.buff(team, "pan", frame.tick);
    return state ? state->effect.damage_multiplier : 1.0;
  };
  const auto square_hit = [](Position a, Position b, int radius) {
    return std::max(std::abs(a.x - b.x), std::abs(a.y - b.y)) <= radius && !same(a, b);
  };
  const auto enemy_range = [&](Position from, Position to, const VisibleEntity& enemy) {
    const auto state = events_.buff(enemy.team.value_or(""), "unrivaled", frame.tick);
    return state ? square_hit(from, to, state->effect.attack_radius) : in_range(from, to);
  };
  const auto defend_probability = [&](const VisibleEntity& enemy) {
    return enemy.defending.value_or(false) ? active_weights.events.purity_defend_seen
                                           : active_weights.events.purity_defend_other;
  };
  // 只有可确认的Buff改变攻击模型；敌方未被观察的行为保持不确定，不凭历史位置射击。
  const auto estimated_damage = [&](const VisibleEntity& enemy) {
    if (enemy.spawn_protected.value_or(false))
      return 0.0;
    const double normal = own_unrivaled ? own_unrivaled->effect.attack_damage : 20.0;
    const double defended = own_unrivaled ? own_unrivaled->effect.defended_damage : 10.0;
    double damage = purity          ? normal * (1.0 - defend_probability(enemy))
                    : own_unrivaled ? (normal + defended) * 0.5
                                    : active_weights.attack_damage_estimate;
    damage *= multiplier(enemy.team.value_or(""));
    if (enemy.hp)
      damage = std::min(damage, *enemy.hp);
    const double min_hit = defended * multiplier(enemy.team.value_or(""));
    if (enemy.hp && *enemy.hp <= min_hit)
      damage += active_weights.kill_reward_estimate * (purity ? 1.0 - defend_probability(enemy) : 1.0);
    return damage;
  };
  const auto event_attack_gain = [&](const VisibleEntity& enemy) {
    if (!own_unrivaled && !purity && multiplier(enemy.team.value_or("")) == 1.0)
      return attack_gain(enemy, frame, active_weights);
    return damage_gain(frame, active_weights, estimated_damage(enemy));
  };
  const auto clear_enemy_hit = [&](Position at, const VisibleEntity* enemy,
                                   const std::vector<const VisibleEntity*>& robots) {
    if (enemy->spawn_protected.value_or(false) || !enemy_range(enemy->position, at, *enemy))
      return false;
    if (events_.buff(enemy->team.value_or(""), "unrivaled", frame.tick))
      return true;
    for (const auto* other : robots)
      if (other != enemy && !same(other->position, at) &&
          distance(enemy->position, other->position) < distance(enemy->position, at) &&
          distance(enemy->position, other->position) + distance(other->position, at) ==
              distance(enemy->position, at))
        return false;
    return true;
  };
  const auto event_threats = [&](Position at, const std::vector<const VisibleEntity*>& robots) {
    int count = 0;
    for (const auto* enemy : robots)
      if (clear_enemy_hit(at, enemy, robots))
        ++count;
    return count;
  };
  const auto current_damage_bound = [&](bool defend) {
    if (frame.self.spawn_protected)
      return 0.0;
    double total = 0;
    for (const auto* enemy : visible)
      if (clear_enemy_hit(frame.self.position, enemy, visible)) {
        const auto buff = events_.buff(enemy->team.value_or(""), "unrivaled", frame.tick);
        total += buff ? (defend ? buff->effect.defended_damage : buff->effect.attack_damage)
                      : (defend ? 10.0 : 20.0);
      }
    return total * multiplier(frame.self.team);
  };
  const auto motion = estimate_opponent_motion(frame, old, visible, memory_);
  plan_.opponent_motion = motion.details;
  std::vector<const VisibleEntity*> projected;
  for (const auto& enemy : motion.projected)
    projected.push_back(&enemy);
  const bool use_intents = active_weights.intent_chase_weight > 0 || active_weights.intent_risk_weight > 0 ||
                           active_weights.third_party_risk_discount > 0 ||
                           active_weights.third_party_attack_bonus > 0 || active_weights.purpose.enabled;
  OpponentIntentModel intents;
  std::vector<VisibleEntity> intent_bodies;
  if (use_intents) {
    intents = assess_opponent_intents(frame, old, intent_previous_, memory_, visible,
                                      active_weights.intent_memory_ticks, active_weights.intent_heading_weight);
    if(active_weights.combat_clue_weight>0) for(std::size_t i=0;i<intents.opponents.size();++i) {
      auto& intent=intents.opponents[i];
      intent.third_party_confidence=std::max(intent.third_party_confidence,
          std::min(.6,active_weights.combat_clue_weight*battle_evidence_.engagement(
              BattleEvidence::identity(intent.entity),frame.tick,active_weights.third_party_memory_ticks)));
      if(i<intents.details.size()) intents.details[i]["third_party_confidence"]=intent.third_party_confidence;
    }
    plan_.opponent_intents = intents.details;
    for (const auto* enemy : visible)
      intent_bodies.push_back(*enemy);
  }
  intent_previous_ = old;
  const auto size = frame.map;
  const Position start = frame.self.position;
  const int count = size.width * size.height;
  InterceptForecast intercepts;
  if(active_weights.purpose.enabled&&active_weights.purpose.intercept_weight>0) {
    intercepts=forecast_intercepts(frame,old,intents,visible.size(),active_weights.purpose,
      [&](Position p){return inside(p,size)&&memory_.cells()[MapMemory::index(p,size)]!=100&&
          events_.terrain_at(p,frame.tick,memory_)!=100;},
      [&](Position p){return memory_.cells()[MapMemory::index(p,size)]==0;});
    plan_.purpose["intercepts"]=intercepts.details;
  }
  // 只记录本车真正看到过的区域；全图已开不意味着一直知道敌车当前在哪里。
  for (int y = std::max(0, start.y - frame.vision_radius);
       y <= std::min(size.height - 1, start.y + frame.vision_radius); ++y) {
    for (int x = std::max(0, start.x - frame.vision_radius);
         x <= std::min(size.width - 1, start.x + frame.vision_radius); ++x)
      last_observed_tick_[cell({x, y}, size)] = frame.tick;
  }
  std::vector<bool> blocked(static_cast<std::size_t>(count), false);
  planning::SearchOptions options;
  for (const auto& [position, until] : blocked_retry_until_) {
    (void)until;
    const Position p{position.first, position.second};
    if (!same(p, start)) {
      blocked[cell(p, size)] = true;
      options.blocked_cells.push_back({p.x, p.y});
    }
  }
  for (const auto* enemy : visible) {
    blocked[cell(enemy->position, size)] = true;
    options.blocked_cells.push_back({enemy->position.x, enemy->position.y});
  }
  // 已解释的危险格在规划窗口内保守避开；不把未知自然语言自动当作已理解。
  const bool avoid_event = event_ && !event_->timeline && event_->end_tick > frame.tick &&
                           event_->begin_tick - frame.tick < remaining_ticks;
  const bool inside_danger =
      avoid_event && std::any_of(event_->dangerous_cells.begin(), event_->dangerous_cells.end(),
                                 [&](Position p) { return same(p, start); });
  // 已经身在危险区时必须允许沿区内格子走向出口，不能把自己的撤离路线全部封死。
  if (avoid_event && !inside_danger) {
    for (auto p : event_->dangerous_cells) {
      if (!same(p, start)) {
        blocked[cell(p, size)] = true;
        options.blocked_cells.push_back({p.x, p.y});
      }
    }
  }
  /// 当前地图下的实际可通行条件；未知格先观察，不直接向未知障碍迈步。
  const auto passable = [&](Position p) {
    return inside(p, size) && !blocked[cell(p, size)] &&
           memory_.cells()[MapMemory::index(p, size)] == 0;
  };
  std::vector<int> dist(static_cast<std::size_t>(count), -1);
  std::vector<Position> parent(static_cast<std::size_t>(count), start);
  std::queue<Position> pending;
  dist[cell(start, size)] = 0;
  pending.push(start);
  while (!pending.empty()) {
    const auto p = pending.front();
    pending.pop();
    for (auto step : kSteps) {
      Position next{p.x + step.x, p.y + step.y};
      if (!passable(next) || dist[cell(next, size)] >= 0)
        continue;
      dist[cell(next, size)] = dist[cell(p, size)] + 1;
      parent[cell(next, size)] = p;
      pending.push(next);
    }
  }

  // 等步长四邻接网格上，BFS距离与A*最短路长度相同。每名可见敌车只算一次，
  // 复用于全部资源；仅用已知空地/障碍，未知区未连通不推断无路，不读取敌方私有视野。
  // 其他车辆的占位和事件绕行不是永久地形，估计敌方路程时不据此封路。
  std::vector<int> nearest_enemy(static_cast<std::size_t>(count), -1);
  if (active_weights.astar_resource_competition || active_weights.resource_race.enabled) {
    for (const auto* enemy : visible) {
      std::vector<int> enemy_dist(static_cast<std::size_t>(count), -1);
      std::queue<Position> queue;
      enemy_dist[cell(enemy->position, size)] = 0;
      queue.push(enemy->position);
      while (!queue.empty()) {
        const auto at = queue.front();
        queue.pop();
        for (const auto step : kSteps) {
          const Position next{at.x + step.x, at.y + step.y};
          if (!inside(next, size) || enemy_dist[cell(next, size)] >= 0 ||
              memory_.cells()[MapMemory::index(next, size)] != 0)
            continue;
          enemy_dist[cell(next, size)] = enemy_dist[cell(at, size)] + 1;
          queue.push(next);
        }
      }
      for (int i = 0; i < count; ++i)
        if (enemy_dist[i] >= 0 && (nearest_enemy[i] < 0 || enemy_dist[i] < nearest_enemy[i]))
          nearest_enemy[i] = enemy_dist[i];
    }
  }

  // 时间只影响决策偏好，不改变裁判实际计分。越早越重视一次性资源，随后平滑恢复。
  // 仅依据公开记忆判断资源是否可能仍存在；尚有未知区域时不能宣称资源已经耗尽。
  const bool unknown_map =
      std::find(memory_.cells().begin(), memory_.cells().end(), -1) != memory_.cells().end();
  const bool known_resource =
      std::any_of(memory_.entities().begin(), memory_.entities().end(), [&](const auto& item) {
        const auto& remembered = item.second;
        const auto& e = remembered.entity;
        return (e.type == "resource_normal" || e.type == "resource_high") &&
               !remembered.first_missing_tick && e.value && *e.value > 0 &&
               inside(e.position, size) && dist[cell(e.position, size)] > 0;
      });
  bool visible_resource = false;
  if (active_weights.acquisition.enabled) {
    for (const auto& [id,item] : memory_.entities()) {
      (void)id;
      const auto& e=item.entity;
      if ((e.type=="resource_normal" || e.type=="resource_high") && !item.first_missing_tick &&
          item.last_seen_tick==frame.tick && e.value && *e.value>0 && inside(e.position,size) &&
          dist[cell(e.position,size)]>0) { visible_resource=true; break; }
    }
    if (visible_resource || (old && frame.score.resource_value>old->score.resource_value))
      acquisition_last_activity_tick_=frame.tick;
  }
  const auto acquisition=acquisition_preference(active_weights.acquisition,frame.tick,
      acquisition_last_activity_tick_,visible_resource);
  plan_.acquisition_exploration_weight=acquisition.exploration;
  plan_.acquisition_silence_ticks=acquisition.silence_ticks;
  if (active_weights.temporal.enabled)
    plan_.temporal_weights={{"resource_age_ticks",active_weights.resource_age_ticks},
        {"competition_weight",active_weights.competition_weight},
        {"resource_lookahead_weight",active_weights.resource_lookahead_weight},
        {"route_information_weight",active_weights.route_information_weight},
        {"third_party_attack_bonus",active_weights.third_party_attack_bonus},
        {"third_party_risk_discount",active_weights.third_party_risk_discount}};
  const double opening =
      active_weights.opening_ticks > 0 && (unknown_map || known_resource)
          ? std::clamp(1.0 - static_cast<double>(frame.tick) / active_weights.opening_ticks, 0.0, 1.0)
          : 0.0;
  // 当前攻击先于移动结算：可能被当场击毁时，撤回额外的抢资源加成，保留原有防御判断。
  const bool lethal_exposure =
      !frame.self.spawn_protected && frame.self.hp <= current_damage_bound(false);
  plan_.economy = assess_resource_economy(memory_, frame, active_weights);
  if (active_weights.enemy_belief_tracking)
    enemy_beliefs_.update(frame,memory_,active_weights.recent_enemy_half_life,active_weights.recent_enemy_max_age);
  navigation_progress_.observe(frame,static_cast<int>(std::count_if(last_observed_tick_.begin(),
      last_observed_tick_.end(),[](auto tick){return tick>=0;})),active_weights);
  plan_.navigation_cycle_active=navigation_progress_.active();
  plan_.navigation_cycle_breaks=navigation_progress_.breaks();
  // 采集欲望可独立降到小于1的终值；只调决策偏好，真实资源/任务分数不变。
  // 低血致命暴露时撤销阶段偏好，仍交给统一生存代价比较。
  const double desired_resource_weight = active_weights.acquisition.enabled ? acquisition.resource :
      active_weights.resource_weight_end +
      (active_weights.opening_resource_weight - active_weights.resource_weight_end) * opening;
  const double resource_weight = active_weights.acquisition.enabled ? desired_resource_weight :
      1.0 + (desired_resource_weight - 1.0) *
                                           (lethal_exposure ? 0.0 : 1.0) *
                                           plan_.economy.collection_factor;
  double combat_weight = collection_linear(active_weights.opening_combat_weight,
      active_weights.combat_weight_end, frame.tick, active_weights.combat_ramp_ticks);
  const double resource_mission_weight = resource_mission_weight_at(active_weights, frame.tick);
  const double reach_weight = reach_priority_at(active_weights, frame.tick, remaining_ticks, -1,
                                               unknown_map || known_resource);
  // 保分的提前量由已知安全区的最短路、伤害缺口、血量和缓冲共同决定。
  // 安全只是相对当前可见敌人的一步活动范围，不宣称视野外没有敌人。
  std::optional<Position> retreat_target;
  int escape_steps = std::numeric_limits<int>::max();
  if (active_weights.endgame_preserve_weight > 0 && !visible.empty() &&
      frame.score.effective_damage >= active_weights.damage_cap * active_weights.retreat_damage_fraction) {
    const auto safe = [&](Position p) {
      for (std::size_t i = 0; i < visible.size(); ++i)
        if (distance(p, visible[i]->position) < 4 || distance(p, projected[i]->position) < 4)
          return false;
      return true;
    };
    if (safe(start))
      escape_steps = 0;
    for (int y = 0; y < size.height; ++y) {
      for (int x = 0; x < size.width; ++x) {
        const Position at{x, y};
        const int steps = dist[cell(at, size)];
        if (steps > 0 && steps < escape_steps && safe(at)) {
          escape_steps = steps;
          retreat_target = at;
        }
      }
    }
    if (escape_steps != std::numeric_limits<int>::max()) {
      plan_.escape_steps = escape_steps;
      const int gap_ticks = static_cast<int>(
          std::ceil(std::max(0.0, active_weights.damage_cap - frame.score.effective_damage) /
                    active_weights.attack_damage_estimate));
      const int hp_buffer =
          static_cast<int>(std::ceil(std::max(0.0, 100.0 - frame.self.hp) / 25.0));
      plan_.retreat_lead_ticks =
          std::min(active_weights.retreat_window_ticks,
                   escape_steps + active_weights.retreat_buffer_ticks + gap_ticks + hp_buffer);
      plan_.preserving_score = remaining_ticks <= plan_.retreat_lead_ticks;
      if (plan_.preserving_score)
        combat_weight /= 1.0 + active_weights.endgame_preserve_weight;
    }
  }
  plan_.opening_fraction = opening;
  plan_.resource_weight = resource_weight;
  plan_.combat_weight = combat_weight;
  plan_.reach_weight = reach_weight;

  // 对预告区域计算撤离距离，首步进入后仍须来得及在结算开始前离开。
  std::map<std::string,EventEscapeField> escape_fields;
  if(active_weights.events.escape_weight>0)
    for(const auto& [id,e]:events_.effects())
      if(e.actor.empty()&&(e.kind=="explosion"||e.kind=="world_split")&&e.begin_tick>frame.tick)
        escape_fields.emplace(id,EventEscapeField(size,e.cells,passable));
  // 事件软代价按预计到达Tick查询；辣椒为有限代价，只有临时墙进入硬阻挡层。
  const auto event_penalty = [&](Position at, std::int64_t arrival, bool entering = true) {
    double penalty = 0;
    for (const auto& [id, e] : events_.effects()) {
      (void)id;
      if (!e.actor.empty())
        continue;
      if ((e.kind == "explosion" || e.kind == "world_split") &&
          Stage2Events::contains(e.cells, at) && arrival < e.end_tick &&
          arrival + active_weights.events.evacuation_buffer >= e.begin_tick) {
        const double scale = e.kind == "world_split" ? 1.0 : std::max(0.1, e.damage / 100.0);
        penalty += active_weights.events.blast_risk * scale /
                   (1 + std::max<std::int64_t>(0, e.begin_tick - arrival));
      }
      const auto escape=escape_fields.find(id);
      if(escape!=escape_fields.end()&&Stage2Events::contains(e.cells,at)&&arrival<e.begin_tick){
        const int steps=escape->second.distance(at);
        const auto available=e.begin_tick-arrival;
        if(steps<0||steps+active_weights.events.evacuation_buffer>available)
          penalty+=active_weights.events.escape_weight*active_weights.events.blast_risk;
      }
      if (e.kind == "pepper" && e.begin_tick <= arrival && arrival < e.end_tick) {
        if (entering && Stage2Events::contains(e.points, at))
          penalty += active_weights.events.pepper_cost;
        if (!frame.self.spawn_protected)
          for (const auto point : e.points) {
            if (same(point, at) || (point.x != at.x && point.y != at.y))
              continue;
            for (const auto* enemy : visible)
              if (distance(enemy->position, point) == 1)
                penalty += e.damage * active_weights.hp_loss_cost * 0.25;
          }
      }
    }
    return penalty;
  };
  std::vector<double> event_route_cost(static_cast<std::size_t>(count), 0.0);
  bool weighted_event_route = false;
  for (int y = 0; y < size.height; ++y)
    for (int x = 0; x < size.width; ++x) {
      const Position p{x, y};
      const int steps = dist[cell(p, size)];
      if (steps >= 0) {
        event_route_cost[cell(p, size)] = event_penalty(p, frame.tick + steps);
        weighted_event_route = weighted_event_route || event_route_cost[cell(p, size)] > 0;
      }
    }
  const double combat_need =
      std::clamp(1.0 - frame.score.effective_damage / active_weights.damage_cap, 0.0, 1.0);
  const auto fortress_reward = [&](const Stage2EventEffect& e, Position at) {
    if (e.kind != "unrivaled" || !e.actor.empty() || e.end_tick <= frame.tick || own_unrivaled)
      return 0.0;
    const int travel = inside(at, size) ? dist[cell(at, size)] : -1;
    const int needed = std::max(1, e.stay_ticks - events_.progress(e, frame.self.team));
    if (travel < 0 ||
        std::max<std::int64_t>(e.begin_tick, frame.tick + travel) + needed >= e.end_tick)
      return 0.0;
    return active_weights.events.fortress_value * (0.15 + 0.85 * combat_need);
  };
  const auto hold_reward = [&](Position destination) {
    double gain = 0;
    for (const auto& [id, e] : events_.effects()) {
      (void)id;
      if (e.kind == "unrivaled" && frame.tick < e.end_tick &&
          Stage2Events::contains(e.cells, start) && Stage2Events::contains(e.cells, destination)) {
        const int needed = std::max(1, e.stay_ticks - events_.progress(e, frame.self.team));
        gain = std::max(gain, active_weights.events.fortress_hold * fortress_reward(e, start) /
                                  (needed + active_weights.travel_offset));
      }
    }
    return gain;
  };
  std::vector<const MissionInfo*> unfinished;
  for (const auto& mission : frame.missions) {
    if (std::find(frame.score.mission_completed_ids.begin(),
                  frame.score.mission_completed_ids.end(),
                  mission.id) != frame.score.mission_completed_ids.end())
      continue;
    if (mission.type != "reach" && mission.type != "normal_resources" &&
        mission.type != "high_resources" && mission.type != "resource_value" &&
        mission.type != "effective_damage") {
      ++plan_.unsupported_missions;
      continue;
    }
    unfinished.push_back(&mission);
  }
  // 已开图仍会失去对敌人的实时了解。旧区域只在伤害/任务仍有收益时奖励重新观察，
  // 达到计分上限后不为了陈旧度无休止巡游；不把老资源位置当成会自动刷新的资源。
  double search_gain =
      marginal(frame.score.effective_damage, 20.0, active_weights.damage_cap, active_weights.damage_points);
  for (const auto* mission : unfinished) {
    if (mission->type == "effective_damage" && mission->target &&
        *mission->target > frame.score.effective_damage)
      search_gain += active_weights.mission_points * active_weights.mission_potential *
                     std::min(1.0, 20.0 / (*mission->target - frame.score.effective_damage));
  }
  // 观测时效可延后至采集窗口之后，再平滑增大，避免刚开局就返回旧区域找人。
  const double observation_phase =
      frame.tick < active_weights.observation_start_tick ? 0.0
      : active_weights.observation_ramp_ticks > 0
          ? std::clamp(static_cast<double>(frame.tick - active_weights.observation_start_tick) /
                           active_weights.observation_ramp_ticks,
                       0.0, 1.0)
          : 1.0;
  std::optional<ObservationAgeField> age_field;
  if (active_weights.observation_age_weight > 0 && observation_phase > 0 && search_gain > 0)
    age_field.emplace(size, memory_.cells(), last_observed_tick_, frame.tick,
                      active_weights.observation_fresh_ticks, active_weights.observation_stale_ticks);
  const FrontierOpportunityValue frontier_value(frame, memory_, active_weights, normal_collected_,
                                                high_collected_);
  std::vector<double> unknown_supply(static_cast<std::size_t>(count),1.);
  if(active_weights.opening_depletion_weight>0) for(int y=0;y<size.height;++y) for(int x=0;x<size.width;++x)
    unknown_supply[cell({x,y},size)]=battle_evidence_.supply_factor({x,y},frame.tick,active_weights);
  plan_.frontier_value = frontier_value.describe();
  /// 计算到目标后能新观察的未知格奖励；越靠近地图边界权重略高，奖励有上限。
  const auto information = [&](Position p) {
    double cells = 0;
    double expected_unknown_cells = 0;
    for (int y = std::max(0, p.y - frame.vision_radius);
         y <= std::min(size.height - 1, p.y + frame.vision_radius); ++y) {
      for (int x = std::max(0, p.x - frame.vision_radius);
           x <= std::min(size.width - 1, p.x + frame.vision_radius); ++x) {
        if (memory_.cells()[MapMemory::index({x, y}, size)] != -1)
          continue;
        expected_unknown_cells+=unknown_supply[cell({x,y},size)];
        const int edge = std::min({x, y, size.width - 1 - x, size.height - 1 - y});
        cells += 1.0 + active_weights.edge_information_bonus / (1.0 + edge);
      }
    }
    return exploration_value(
               cells * active_weights.information_per_cell + frontier_value.extra(expected_unknown_cells),
               active_weights.information_cap, active_weights.information_softness) *
           plan_.economy.exploration_factor * acquisition.exploration;
  };
  std::optional<Candidate> best;
  // 没有可见可达资源持续一段时间后，允许提前转战；发现新资源时仍能重新评估采集。
  // 沉默只是本队的机会信号，不宣称未知地图上已经没有资源，原探索候选继续保留。
  if (active_weights.phase.enabled||active_weights.purpose.enabled)
    for (const auto& entity : frame.visible_entities)
      if ((entity.type == "resource_normal" || entity.type == "resource_high") &&
          entity.value && *entity.value > 0 && inside(entity.position, size) &&
          dist[cell(entity.position, size)] > 0)
        phase_last_resource_tick_ = frame.tick;
  plan_.phase_resource_age = std::max<std::int64_t>(0, frame.tick - phase_last_resource_tick_);
  const bool collection_opportunity = (unknown_map || known_resource) &&
      (active_weights.phase.resource_silence_ticks == 0 ||
       plan_.phase_resource_age <= active_weights.phase.resource_silence_ticks);
  const auto phase = stage2_phase(active_weights.phase, frame.tick,
      frame.score.resource_value < active_weights.resource_cap ||
        std::any_of(unfinished.begin(), unfinished.end(), [](const auto* m) {
          return m->type == "normal_resources" || m->type == "high_resources" ||
                 m->type == "resource_value";
        }), collection_opportunity, search_gain > 0);
  plan_.phase = stage2_phase_name(phase);
  std::optional<Candidate> phase_best;
  std::optional<Candidate> phase_resource;
  std::optional<Candidate> deadline_mission;
  std::optional<Candidate> purpose_resource;
  std::optional<Candidate> purpose_battle;
  // 单个任务距离场复用于全部交战候选：估计“先交战、再顺路到任务”的后续路程。
  // 只在刷伤害阶段启用，不把这笔私有任务预期叠加到开局资源欲望上。
  std::vector<std::vector<int>> task_distance_fields;
  if (phase == Stage2Phase::Fight && active_weights.phase.task_lookahead_weight > 0)
    for (const auto* m : unfinished)
      if (m->type == "reach" && m->position && inside(*m->position, size) &&
          dist[cell(*m->position, size)] >= 0)
        task_distance_fields.push_back(goal_distance_field(size, *m->position, passable));
  Stage2JointPlan joint_plan;
  ResourceSweepPlan sweep_plan;
  CollectionSearchPlan collection_search_plan;
  ResourceRacePlan resource_race_plan;
  Stage2JointPlan race_coverage_plan;
  std::optional<Candidate> resource_priority;
  bool prefer_joint = false;
  /// 所有类型目标统一比较“可得分+信息价值 / 路程”，减去路径风险并保留轻微惯性。
  const auto consider = [&](Candidate candidate) {
    if (prefer_joint && !candidate.joint &&
        (candidate.kind == "resource" || candidate.kind == "explore"))
      return;
    if (!inside(candidate.position, size))
      return;
    const int steps = dist[cell(candidate.position, size)];
    if (steps <= 0 || steps > remaining_ticks)
      return;
    ++plan_.candidates;
    if (!candidate.sweep && !candidate.collection_search)
      candidate.information = information(candidate.position);
    if (age_field) {
      candidate.age_information =
          std::min(std::max(0.0, active_weights.information_cap - candidate.information),
                   active_weights.observation_age_weight * observation_phase * search_gain *
                       age_field->mean_in_view(candidate.position, frame.vision_radius) *
                       plan_.economy.exploration_factor);
      candidate.information += candidate.age_information;
    }
    if(active_weights.combat_clue_weight>0&&search_gain>0)
      candidate.patrol+=active_weights.combat_clue_weight*search_gain*
          battle_evidence_.in_view(candidate.position,frame.vision_radius);
    if (candidate.resource + candidate.mission + candidate.combat + candidate.information +
            candidate.patrol + candidate.event_reward <=
        0)
      return;  // 目标惯性不能凭空让已无收益的旧目标继续存在。
    double risk = event_penalty(candidate.position, frame.tick + steps);
    Position p = candidate.position;
    while (dist[cell(p, size)] > 2)
      p = parent[cell(p, size)];
    while (!same(p, start)) {
      risk += event_threats(p, visible) * active_weights.route_risk;
      risk += active_weights.combat_clue_weight*battle_evidence_.exposure(p)*active_weights.route_risk;
      risk += event_penalty(p, frame.tick + dist[cell(p, size)]);
      p = parent[cell(p, size)];
    }
    for (const auto& [key, memory] : memory_.entities()) {
      (void)key;
      const auto age = frame.tick - memory.last_seen_tick;
      if (memory.entity.type == "robot" && (!memory.entity.hp||*memory.entity.hp>0) &&
          !memory.first_missing_tick && age > 0 &&
          age <= active_weights.enemy_memory_ticks &&
          distance(memory.entity.position, candidate.position) <= 2)
        risk += active_weights.remembered_risk / (1.0 + age);
    }
    const double visible_weight =
        candidate.visible_resource ? active_weights.visible_resource_weight : 1.0;
    const double collection_weight =
        candidate.kind == "resource" ? resource_weight * visible_weight : 1.0;
    const double mission_weight =
        candidate.kind == "resource"
            ? resource_mission_weight * (active_weights.adaptive_resources
                                                      ? active_weights.collection_mission_weight
                                                      : resource_weight) * visible_weight
            : (candidate.reach_priority >= 0 ? candidate.reach_priority : reach_weight);
    // 新搜索已按整段到达时间扣除风险；这里不能重复扣一次目标/首两步风险。
    if(candidate.collection_search) risk=0;
    candidate.utility = (candidate.sweep||candidate.collection_search) ? candidate.planned_utility - risk :
                        (candidate.resource * collection_weight +
                         candidate.mission * mission_weight + candidate.combat * combat_weight +
                         candidate.information + candidate.patrol + candidate.event_reward) /
                            (steps + active_weights.travel_offset) -
                        risk + candidate.future_utility;
    if (candidate.kind + ":" + candidate.id == previous_goal_) {
      candidate.switch_bonus = active_weights.switch_margin;
      candidate.utility += candidate.switch_bonus;
    }
    if (candidate.kind == "combat" || candidate.kind == "search_enemy" || candidate.kind == "patrol")
      for (const auto& field : task_distance_fields) {
        const int after = field[cell(candidate.position, size)];
        if (after >= 0 && steps + after <= remaining_ticks)
          candidate.utility += active_weights.phase.task_lookahead_weight * active_weights.mission_points *
              active_weights.mission_potential / (steps + after + active_weights.travel_offset);
      }
    if (candidate.utility > 0 && stage2_phase_goal(phase, candidate.kind, steps,
                                                 active_weights.phase.chase_steps) &&
        (!phase_best || candidate.utility > phase_best->utility + 1e-9))
      phase_best = candidate;
    if (phase == Stage2Phase::Collect && candidate.kind == "resource" &&
        candidate.visible_resource && steps <= active_weights.phase.visible_resource_steps &&
        candidate.resource + candidate.mission > 0 && candidate.utility > 0 &&
        (!phase_resource || candidate.utility > phase_resource->utility + 1e-9))
      phase_resource = candidate;
    if (candidate.utility > 0 && candidate.kind == "mission" &&
        remaining_ticks <= steps + active_weights.reach_deadline_buffer &&
        (!deadline_mission || candidate.utility > deadline_mission->utility + 1e-9))
      deadline_mission = candidate;
    if(active_weights.purpose.enabled&&candidate.utility>0) {
      if(candidate.kind=="resource"&&candidate.resource+candidate.mission>0&&
          (!purpose_resource||candidate.utility>purpose_resource->utility+1e-9))
        purpose_resource=candidate;
      if((candidate.kind=="combat"||candidate.kind=="search_enemy"||candidate.kind=="patrol"||
          candidate.kind.rfind("event_",0)==0)&&
          (!purpose_battle||candidate.utility>purpose_battle->utility+1e-9))
        purpose_battle=candidate;
    }
    if (candidate.utility > 0 && (!best || candidate.utility > best->utility + 1e-9))
      best = candidate;
  };

  std::vector<std::pair<std::string, Candidate>> resource_candidates;
  std::vector<JointOpportunity> opportunities;
  std::vector<RaceResource> race_resources;
  for (const auto& [key, memory] : memory_.entities()) {
    const auto& entity = memory.entity;
    if ((entity.type != "resource_normal" && entity.type != "resource_high") ||
        memory.first_missing_tick || !entity.value)
      continue;
    Candidate c{"resource", entity.id.value_or(key), entity.position};
    c.visible_resource = memory.last_seen_tick == frame.tick;
    JointOpportunity opportunity;
    opportunity.key = key;
    opportunity.position = entity.position;
    opportunity.value = *entity.value;
    const double age = static_cast<double>(frame.tick - memory.last_seen_tick);
    double confidence = 1.0 / (1.0 + age / active_weights.resource_age_ticks);
    if (active_weights.resource_race.enabled && inside(entity.position, size) &&
        dist[cell(entity.position, size)] > 0)
      race_resources.push_back({key, entity.position, *entity.value, confidence,
                                nearest_enemy[cell(entity.position, size)]});
    double race_factor = 1.0;
    if (inside(entity.position, size) && dist[cell(entity.position, size)] >= 0) {
      if (active_weights.astar_resource_competition) {
        race_factor = collection_race_factor(dist[cell(entity.position, size)],
                                             nearest_enemy[cell(entity.position, size)], frame.tick,
                                             active_weights);
        confidence *= race_factor;
      } else {
        for (const auto* enemy : visible) {
          if (distance(enemy->position, entity.position) <= dist[cell(entity.position, size)]) {
            confidence *= active_weights.contested_resource_factor;
            break;
          }
        }
      }
    }
    plan_.resource_races.push_back(
        {{"id", c.id},
         {"position", {entity.position.x, entity.position.y}},
         {"visible", c.visible_resource},
         {"age_ticks", frame.tick - memory.last_seen_tick},
         {"own_steps", dist[cell(entity.position, size)]},
         {"nearest_visible_enemy_steps", nearest_enemy[cell(entity.position, size)]},
         {"race_factor", race_factor},
         {"confidence", confidence}});
    c.resource = marginal(frame.score.resource_value, *entity.value, active_weights.resource_cap,
                          active_weights.resource_points) *
                 confidence;
    for (const auto* mission : unfinished) {
      if (!mission->target || *mission->target <= 0)
        continue;
      double left = 0, progress = 0;
      if (mission->type == "normal_resources" && entity.type == "resource_normal") {
        left = *mission->target - normal_collected_;
        progress = 1;
      } else if (mission->type == "high_resources" && entity.type == "resource_high") {
        left = *mission->target - high_collected_;
        progress = 1;
      } else if (mission->type == "resource_value") {
        left = *mission->target - frame.score.resource_value;
        progress = *entity.value;
      }
      if (left > 0) {
        const double gain = active_weights.mission_points * active_weights.mission_potential *
                            std::min(1.0, progress / left) * confidence;
        c.mission += gain;
        opportunity.mission_points[mission->id] = gain;
      }
    }
    if (active_weights.astar_resource_competition)
      opportunity.value *= confidence;  // 路线排序也承认争抢和记忆折扣，不能只折扣最终分数。
    const double visible_weight = c.visible_resource ? active_weights.visible_resource_weight : 1.0;
    opportunity.value *= visible_weight;
    resource_candidates.emplace_back(key, c);
    if (dist[cell(entity.position, size)] > 0 && c.resource + c.mission > 0) {
      opportunity.resource_points = c.resource;
      opportunity.direct_steps=dist[cell(entity.position,size)];
      opportunity.nearest_enemy_steps=nearest_enemy[cell(entity.position,size)];
      opportunity.preference=visible_weight;
      opportunity.priority =
          (c.resource + c.mission) * visible_weight /
          (dist[cell(entity.position, size)] + active_weights.travel_offset);
      opportunities.push_back(opportunity);
    }
  }
  const bool collection_task = std::any_of(unfinished.begin(), unfinished.end(), [](const auto* m) {
    return m->type == "normal_resources" || m->type == "high_resources" ||
           m->type == "resource_value";
  });
  if(active_weights.collection_search_weight>0&&frame.tick<active_weights.collection_search_ticks&&
     (unknown_map||frame.score.resource_value<active_weights.resource_cap||collection_task)) {
    const double mission_weight=resource_mission_weight*
        (active_weights.adaptive_resources?active_weights.collection_mission_weight:resource_weight);
    collection_search_plan=search_collection_route(frame,memory_,opportunities,
        static_cast<int>(remaining_ticks),active_weights,resource_weight,mission_weight,passable,
        [&](double cells,double edge_cells) {
          return exploration_value(edge_cells*active_weights.information_per_cell+frontier_value.extra(cells),
              active_weights.information_cap,active_weights.information_softness)*plan_.economy.exploration_factor*acquisition.exploration;
        },[&](Position at,int arrival) {
          const double future=std::exp2(-static_cast<double>(arrival-1)/6.0);
          return event_penalty(at,frame.tick+arrival)+
              future*(event_threats(at,visible)+active_weights.combat_clue_weight*battle_evidence_.exposure(at))*active_weights.route_risk;
        },unknown_supply);
    const auto& search=collection_search_plan;
    plan_.collection_search={{"ran",search.ran},{"expanded",search.expanded},
        {"completed_depth",search.completed_depth},{"targets",search.targets},
        {"elapsed_ms",search.elapsed_ms},{"budget_hit",search.budget_hit},
        {"forecast_resource",search.forecast_resource},{"forecast_mission",search.forecast_mission}};
    if(search.route.success()&&search.route.path.size()>1) {
      const auto end=search.route.path.back();
      Candidate c{search.first_resource.empty()?"explore":"resource",
          "search:"+search.first_resource,{end.x,end.y}};
      c.collection_search=true;c.planned_utility=search.utility;
      c.resource=search.resource_points;c.mission=search.mission_points;
      c.information=search.information_points;consider(c);
    }
  }
  if (active_weights.sweep_weight>0 && frame.tick<active_weights.sweep_ticks &&
      (unknown_map || frame.score.resource_value<active_weights.resource_cap || collection_task)) {
    const double mission_weight=resource_mission_weight*
        (active_weights.adaptive_resources?active_weights.collection_mission_weight:resource_weight);
    sweep_plan=resource_sweep(frame,memory_,opportunities,static_cast<int>(remaining_ticks),active_weights,
        resource_weight,mission_weight,passable,[&](int cells,double edge_cells) {
          return exploration_value(edge_cells*active_weights.information_per_cell+frontier_value.extra(cells),
              active_weights.information_cap,active_weights.information_softness)*plan_.economy.exploration_factor*acquisition.exploration;
        });
    if(sweep_plan.path.size()>1) {
      const auto end=sweep_plan.path.back();
      Candidate c{sweep_plan.first_resource.empty()?"explore":"resource",
          "sweep:"+sweep_plan.first_resource,{end.x,end.y}};
      c.sweep=true;c.planned_utility=sweep_plan.utility;
      c.resource=sweep_plan.resource_points;c.mission=sweep_plan.mission_points;
      c.information=sweep_plan.information_points;
      consider(c);
    }
  }
  if (active_weights.collection_mode > 0 && frame.tick < active_weights.joint_ticks &&
      opportunities.size() >= static_cast<std::size_t>(active_weights.joint_min_resources) &&
      (frame.score.resource_value < active_weights.resource_cap || collection_task)) {
    plan_.joint_planned = true;
    joint_plan =
        joint_planner_.propose(frame, memory_, opportunities, options.blocked_cells,
                               remaining_ticks, collection_weights_at(active_weights, frame.tick));
    if (joint_plan.route.success() && joint_plan.route.path.size() > 1) {
      const auto end = joint_plan.route.path.back();
      Candidate c{joint_plan.resource_key.empty() ? "explore" : "resource",
                  "joint:" + joint_plan.resource_key,
                  {end.x, end.y}};
      c.resource = joint_plan.resource_points;
      c.mission = joint_plan.mission_points;
      c.joint = true;
      if (const auto found = memory_.entities().find(joint_plan.resource_key);
          found != memory_.entities().end())
        c.visible_resource = found->second.last_seen_tick == frame.tick;
      c.future_utility = joint_plan.future_utility;
      consider(c);
      prefer_joint = active_weights.collection_mode == 2 && best && best->joint;
    }
  }
  const auto future_resources = resource_lookahead(
      size, opportunities, dist,
      marginal(frame.score.resource_value, active_weights.resource_cap, active_weights.resource_cap,
               active_weights.resource_points),
      active_weights.mission_points * active_weights.mission_potential, resource_weight,
      resource_mission_weight *
          (active_weights.adaptive_resources ? active_weights.collection_mission_weight : resource_weight),
      remaining_ticks, active_weights, passable);
  for (auto& item : resource_candidates) {
    if (const auto future = future_resources.find(item.first); future != future_resources.end())
      item.second.future_utility = future->second;
    consider(item.second);
  }
  // 增益/开关是可达目标收益，不写进静态障碍；数值全部来自已校验模型事件。
  for (const auto& [id, e] : events_.effects()) {
    if (!e.actor.empty() || e.end_tick <= frame.tick)
      continue;
    std::vector<Position> goals;
    double reward = 0;
    if (e.kind == "angel") {
      const double deficit = std::max(0.0, e.hp_cap - frame.self.hp);
      const auto existing = events_.buff(frame.self.team, "angel", frame.tick);
      const double old_heal =
          existing ? std::min(deficit, existing->effect.heal_per_tick *
                                           static_cast<double>(existing->until - frame.tick))
                   : 0.0;
      reward = active_weights.events.heal_value *
               std::max(0.0, std::min(deficit, e.heal_per_tick * e.effect_ticks) - old_heal);
      if(active_weights.interference.modify_events&&active_weights.interference.weight>0&&frame.score.effective_damage>=active_weights.damage_cap)
        reward*=active_weights.interference.heal_multiplier;
      goals = e.points;
    } else if (e.kind == "unrivaled" && !own_unrivaled) {
      // 已在堡垒内时靠驻留收益维持捕获，不再为同一块区域虚构移动收益。
      if (Stage2Events::contains(e.cells, start))
        continue;
      goals = e.cells;
      reward = active_weights.events.fortress_value * (0.15 + 0.85 * combat_need);
    } else if (e.kind == "pepper")
      goals = e.points;
    for (const auto goal : goals) {
      double value = reward;
      if (e.kind == "pepper") {
        if (frame.tick < e.begin_tick)
          continue;
        for (const auto* enemy : visible)
          if (!enemy->spawn_protected.value_or(false) && !same(goal, enemy->position) &&
              (goal.x == enemy->position.x || goal.y == enemy->position.y))
            value += active_weights.events.pepper_value * std::min(e.damage, enemy->hp.value_or(100.0));
      }
      if (value <= 0)
        continue;
      const int travel = inside(goal, size) ? dist[cell(goal, size)] : -1;
      if(active_weights.interference.modify_events&&active_weights.interference.weight>0&&frame.score.effective_damage>=active_weights.damage_cap&&
          (e.kind=="pepper"||e.kind=="unrivaled")) {
        if(travel<0||travel>active_weights.interference.maximum_detour) continue;
        double incoming=current_damage_bound(false);
        // 用当前可见敌人的完整伤害估计短途机关路线，不为骚扰走进明显火力区。
        for(Position at=goal;!same(at,start)&&dist[cell(at,size)]>0;at=parent[cell(at,size)])
          for(const auto* enemy:visible) if(clear_enemy_hit(at,enemy,visible)) {
            const auto buff=events_.buff(enemy->team.value_or(""),"unrivaled",frame.tick);
            incoming+=(buff?buff->effect.attack_damage:20.0)*multiplier(frame.self.team);
          }
        if(!active_weights.interference.safe(frame.self.hp,incoming)) continue;
      }
      const int stay = e.kind == "unrivaled"
                           ? std::max(1, e.stay_ticks - events_.progress(e, frame.self.team))
                           : 0;
      if (travel >= 0 &&
          std::max<std::int64_t>(e.begin_tick, frame.tick + travel) + stay >= e.end_tick)
        continue;
      if (travel > 0) {
        Candidate c{"event_" + e.kind, id, goal};
        c.event_reward = value;
        if (stay > 0)
          c.event_reward *= static_cast<double>(travel + active_weights.travel_offset) /
                            (travel + stay + active_weights.travel_offset);
        consider(c);
      } else if (travel < 0 && e.kind != "pepper") {
        // 已公告的远方位置可以引导开图，但仍只能向本车已知空地移动。
        for (int y = 0; y < size.height; ++y)
          for (int x = 0; x < size.width; ++x) {
            Position at{x, y};
            const int d = dist[cell(at, size)];
            if (d <= 0 || distance(at, goal) >= distance(start, goal) ||
                frame.tick + d + distance(at, goal) + stay >= e.end_tick)
              continue;
            Candidate c{"event_explore", id, at};
            c.event_reward = 0.5 * value / (1 + distance(at, goal));
            consider(c);
          }
      } else if (travel == 0 && e.kind == "angel" && frame.tick >= e.begin_tick &&
                 !events_.buff(frame.self.team, "angel", frame.tick)) {
        for (const auto step : kSteps) {
          const Position at{start.x + step.x, start.y + step.y};
          if (!passable(at))
            continue;
          Candidate c{"event_angel_refresh", id, at};
          c.event_reward = value * 0.5;
          consider(c);
        }
      }
    }
  }
  for (const auto* mission : unfinished) {
    if (mission->type == "reach" && mission->position && inside(*mission->position, size)) {
      Candidate c{"mission", mission->id, *mission->position};
      c.mission = active_weights.mission_points * active_weights.mission_potential;
      const int steps = dist[cell(*mission->position, size)];
      c.reach_priority = reach_priority_at(active_weights, frame.tick, remaining_ticks,
          steps >= 0 ? steps : distance(start, *mission->position), unknown_map || known_resource);
      consider(c);
    }
  }
  for (int y = 0; y < size.height; ++y) {
    for (int x = 0; x < size.width; ++x) {
      Position p{x, y};
      if (dist[cell(p, size)] <= 0)
        continue;
      Candidate explore{"explore", std::to_string(x) + "," + std::to_string(y), p};
      // 远方任务尚未连通时，以探索为主，顺带偏向能接近该公开任务坐标的位置。
      for (const auto* mission : unfinished) {
        if (mission->type == "reach" && mission->position && inside(*mission->position, size) &&
            dist[cell(*mission->position, size)] < 0 &&
            distance(p, *mission->position) < distance(start, *mission->position)) {
          explore.mission += active_weights.mission_points * active_weights.mission_potential /
                             (1.0 + distance(p, *mission->position));
          explore.reach_priority = std::max(explore.reach_priority,
              reach_priority_at(active_weights, frame.tick, remaining_ticks,
                  distance(start, *mission->position), unknown_map || known_resource));
        }
      }
      consider(explore);
      if (frame.self.spawn_protected || remaining_ticks <= dist[cell(p, size)])
        continue;
      for (const auto* enemy : visible) {
        const auto index = static_cast<std::size_t>(
            std::find(visible.begin(), visible.end(), enemy) - visible.begin());
        const bool current_range =
            own_unrivaled ? square_hit(p, enemy->position, own_unrivaled->effect.attack_radius)
                          : in_range(p, enemy->position);
        const auto predicted_position = projected[index]->position;
        const Position predicted_delta{(predicted_position.x > p.x) - (predicted_position.x < p.x),
                                       (predicted_position.y > p.y) - (predicted_position.y < p.y)};
        // 外推场景也遵守最近机器人挡弹，不能假设挡在中间的车凭空消失。
        const bool predicted_range =
            in_range(p, predicted_position) &&
            attack_target(p, predicted_delta, projected) == projected[index];
        const auto delta = Position{(enemy->position.x > p.x) - (enemy->position.x < p.x),
                                    (enemy->position.y > p.y) - (enemy->position.y < p.y)};
        const bool current_hit =
            current_range && (own_unrivaled || attack_target(p, delta, visible) == enemy);
        double opportunity = (1.0 - active_weights.opponent_motion_weight) * current_hit +
                             active_weights.opponent_motion_weight * predicted_range;
        if (active_weights.intent_chase_weight > 0 && !own_unrivaled) {
          const int arrival = dist[cell(p, size)];
          const double delay = std::max(0, arrival - 1);
          const double blend = active_weights.intent_chase_weight / (1.0 + delay * delay);
          opportunity = (1.0 - blend) * current_hit +
                        blend * intent_hit_probability(p, index, intents, intent_bodies);
        }
        const int arrival=dist[cell(p,size)];
        if(active_weights.purpose.enabled&&active_weights.purpose.intercept_weight>0&&
            arrival<=active_weights.purpose.intercept_horizon) {
          const double predicted=intercept_probability(p,index,arrival,intercepts,intent_bodies,
              own_unrivaled?own_unrivaled->effect.attack_radius:0);
          opportunity=(1.0-active_weights.purpose.intercept_weight)*opportunity+
              active_weights.purpose.intercept_weight*predicted;
        }
        if (opportunity <= 0)
          continue;
        const auto target_id = enemy->id.value_or(enemy->team.value_or("enemy"));
        if (pursuit_cooldown_.count(target_id))
          continue;
        Candidate combat{"combat", target_id, p};
        combat.combat = event_attack_gain(*enemy) * opportunity;
        consider(combat);
      }
    }
  }
  // 眼前无人而伤害仍有收益时，用最后看见Tick推算可能位置；旧格为空只排除旧格，
  // 不能把已经移动的敌人整条线索丢弃。未知格仅为软概率，目标和执行路线仍须已知可走。
  if (active_weights.recent_enemy_search_weight > 0 && visible.empty() && search_gain > 0) {
    std::optional<EnemySightingsField> sightings;
    if (!active_weights.enemy_belief_tracking)
      sightings.emplace(frame,memory_,active_weights.recent_enemy_half_life,active_weights.recent_enemy_max_age);
    plan_.recent_enemy_sightings = active_weights.enemy_belief_tracking ? enemy_beliefs_.details : sightings->details;
    for (int y = 0; y < size.height; ++y) {
      for (int x = 0; x < size.width; ++x) {
        const Position p{x, y};
        if (dist[cell(p, size)] <= 0 || dist[cell(p, size)] >= remaining_ticks)
          continue;
        const double probability = active_weights.enemy_belief_tracking
            ? enemy_beliefs_.in_view(p,frame.vision_radius) : sightings->in_view(p,frame.vision_radius);
        if (probability <= 0)
          continue;
        Candidate search{"search_enemy", std::to_string(x) + "," + std::to_string(y), p};
        search.combat =
            search_gain * active_weights.recent_enemy_search_weight * probability *
            std::exp2(-static_cast<double>(dist[cell(p, size)]) / active_weights.recent_enemy_half_life);
        consider(search);
      }
    }
  }
  // 只有常规目标全部失效、战斗仍有收益时才巡查；D已满分时保留安全等待。
  // 价值来自旧区域的信息时效，不把敌人的历史坐标当作当前真实位置。
  const bool visible_pursuit=active_weights.purpose.enabled&&!frame.self.spawn_protected&&
      std::any_of(visible.begin(),visible.end(),[&](const auto* enemy){
        const auto id=enemy->id.value_or(enemy->team.value_or("enemy"));
        return !pursuit_cooldown_.count(id)&&event_attack_gain(*enemy)>0;
      });
  const double patrol_scale=visible_pursuit?active_weights.purpose.patrol_visible_scale:1.0;
  if(active_weights.purpose.enabled)plan_.purpose["visible_pursuit"]=visible_pursuit;
  if ((!best||active_weights.purpose.enabled) && search_gain > 0 && active_weights.patrol_value > 0 && patrol_scale>0) {
    for (int y = 0; y < size.height; ++y) {
      for (int x = 0; x < size.width; ++x) {
        const Position p{x, y};
        const int steps = dist[cell(p, size)];
        if (steps <= 0 || steps >= remaining_ticks)
          continue;  // 至少留一个Tick利用巡查发现的战斗机会。
        double stale = 0;
        int free_cells = 0;
        for (int vy = std::max(0, y - frame.vision_radius);
             vy <= std::min(size.height - 1, y + frame.vision_radius); ++vy) {
          for (int vx = std::max(0, x - frame.vision_radius);
               vx <= std::min(size.width - 1, x + frame.vision_radius); ++vx) {
            if (memory_.cells()[MapMemory::index({vx, vy}, size)] != 0)
              continue;
            ++free_cells;
            const auto last = last_observed_tick_[cell({vx, vy}, size)];
            const auto age = frame.tick - last;
            if (last >= 0 && age >= active_weights.patrol_min_age)
              stale += std::min(1.0, age / active_weights.patrol_stale_ticks);
          }
        }
        if (free_cells == 0 || stale <= 0)
          continue;
        double hint = 0;
        for (const auto& [key, memory] : memory_.entities()) {
          (void)key;
          if (memory.entity.type != "robot" || (memory.entity.hp&&*memory.entity.hp<=0) || memory.first_missing_tick)
            continue;
          const auto age = frame.tick - memory.last_seen_tick;
          hint = std::max(hint, active_weights.patrol_enemy_hint /
                                    (1.0 + age / active_weights.patrol_stale_ticks) /
                                    (1.0 + distance(p, memory.entity.position)));
        }
        Candidate patrol{"patrol", std::to_string(x) + "," + std::to_string(y), p};
        patrol.patrol =
            patrol_scale * search_gain * active_weights.patrol_value * std::min(1.0, stale / free_cells + hint);
        consider(patrol);
      }
    }
  }
  // 明确阶段目标，仍保留机会成本下限；不因分期去追一个几乎不可能收益的远方目标。
  // 临近到达任务最晚出发时间时先补任务；后续紧急事件撤离仍可覆盖这里的选择。
  if (active_weights.phase.enabled) {
    const double floor = phase == Stage2Phase::Fight
        ? active_weights.phase.combat_opportunity_floor : active_weights.phase.opportunity_floor;
    if (deadline_mission) {
      best = deadline_mission;
      plan_.phase_goal_selected = true;
    } else if (phase_resource && (!best || phase_resource->utility >= floor * best->utility)) {
      best = phase_resource;
      plan_.phase_goal_selected = true;
    } else if (phase_best && (!best || phase_best->utility >= floor * best->utility)) {
      best = phase_best;
      plan_.phase_goal_selected = true;
    }
    // 对所选主目标反向BFS一次，检验任务是否真的顺路；不使用曼哈顿距离猜绕路。
    // 只插入位于主目标之前的任务，下一Tick仍重新检查，主目标收益不能重复计分。
    if (best && best->kind != "mission" && !best->joint && !best->sweep &&
        !best->collection_search && active_weights.phase.task_detour >= 0) {
      const auto to_goal = goal_distance_field(size, best->position, passable);
      const int direct = dist[cell(best->position, size)];
      std::optional<Candidate> waypoint;
      int waypoint_steps = std::numeric_limits<int>::max();
      for (const auto* m : unfinished) {
        if (m->type != "reach" || !m->position || !inside(*m->position, size)) continue;
        const int travel = dist[cell(*m->position, size)];
        const int onward = to_goal[cell(*m->position, size)];
        if (travel <= 0 || travel >= direct || onward < 0 ||
            travel + onward > direct + active_weights.phase.task_detour ||
            travel + onward > remaining_ticks || travel >= waypoint_steps) continue;
        Candidate c{"mission", m->id, *m->position};
        c.mission = active_weights.mission_points * active_weights.mission_potential;
        c.utility = best->utility; // 继承主路线价值，只改变本段途经点，不凭空添加收益。
        c.switch_bonus = best->switch_bonus;
        waypoint = c;
        waypoint_steps = travel;
      }
      if (waypoint) { best = waypoint; plan_.task_waypoint = true; }
    }
  }
  // 一次性资源优先贯穿整场：没有开局窗口，晚期新发现同样重新做完整子集规划。
  // 预计对手期限不是消失事实；无确定抢先路线时仍可直接争取，实见消失才删除。
  if (active_weights.resource_race.enabled) {
    // 路线同长时直接比较新未知格数，保留大视野间的差别，不沿用旧评分的饱和上限。
    const auto raw_information = [&](Position p) {
      double cells = 0;
      for (int y=std::max(0,p.y-frame.vision_radius);y<=std::min(size.height-1,p.y+frame.vision_radius);++y)
        for (int x=std::max(0,p.x-frame.vision_radius);x<=std::min(size.width-1,p.x+frame.vision_radius);++x)
          if (memory_.cells()[MapMemory::index({x,y},size)] == -1) cells += unknown_supply[cell({x,y},size)];
      return cells;
    };
    const double point_to_resource = active_weights.resource_cap / active_weights.resource_points;
    for (auto& r : race_resources)
      if (const auto found = std::find_if(opportunities.begin(),opportunities.end(),
          [&](const auto& o){return o.key==r.key;}); found != opportunities.end())
        for (const auto& [id,gain]:found->mission_points)
          r.mission_values[id] = gain * point_to_resource;
    resource_race_plan = plan_resource_race(size, start, race_resources,
        static_cast<int>(remaining_ticks), active_weights.resource_race, passable, raw_information,
        active_weights.mission_points * active_weights.mission_potential * point_to_resource);
    plan_.resource_race = {{"enabled", true}, {"targets", resource_race_plan.targets},
        {"order", resource_race_plan.order}, {"arrivals", resource_race_plan.arrivals},
        {"forecast_value", resource_race_plan.forecast_value},
        {"route_steps", resource_race_plan.route_steps}, {"expanded", resource_race_plan.expanded},
        {"complete", resource_race_plan.complete}, {"elapsed_ms", resource_race_plan.elapsed_ms},
        {"contested_fallback", resource_race_plan.contested_fallback}, {"coverage", false}};
    if (resource_race_plan.route.success() && resource_race_plan.route.path.size() > 1) {
      const auto& key = resource_race_plan.order.front();
      const auto at = resource_race_plan.route.path.back();
      Candidate candidate{"resource", "race:" + key, {at.x, at.y}};
      if (const auto found = std::find_if(resource_candidates.begin(), resource_candidates.end(),
          [&](const auto& item) { return item.first == key; }); found != resource_candidates.end()) {
        candidate.resource = found->second.resource;
        candidate.mission = found->second.mission;
        candidate.visible_resource = found->second.visible_resource;
      }
      candidate.resource_race = true;
      candidate.utility = std::max(active_weights.resource_race.move_priority,
          (candidate.resource * resource_weight + candidate.mission * resource_mission_weight) /
          (resource_race_plan.route.cost + active_weights.travel_offset));
      resource_priority = candidate;
    } else if (active_weights.resource_race.coverage_fallback && unknown_map &&
               frame.tick < active_weights.resource_race.explore_ticks &&
               (frame.score.resource_value < active_weights.resource_cap || collection_task)) {
      auto cover_weights = collection_weights_at(active_weights, frame.tick);
      cover_weights.joint_observation_offset = active_weights.resource_race.coverage_offset;
      if (active_weights.resource_race.explore_method == 0) {
        race_coverage_plan = race_coverage_planner_.propose(frame, memory_, {}, options.blocked_cells,
                                                         remaining_ticks, cover_weights);
      } else {
        // 未知资源探索：比较新增视野/实际路程，并用可见敌人的到达下界修正争抢价值。
        // 不硬编码向中央或边界走；边缘、争抢、紧迫性与距离指数均独立训练。
        double best_density = 0;
        std::optional<Position> observation;
        const auto& rw = active_weights.resource_race;
        for (int y=0;y<size.height;++y) for (int x=0;x<size.width;++x) {
          const Position p{x,y}; const int steps=dist[cell(p,size)];
          if (steps<=0 || steps>remaining_ticks) continue;
          double gain=0;
          for (int vy=std::max(0,y-frame.vision_radius);vy<=std::min(size.height-1,y+frame.vision_radius);++vy)
            for (int vx=std::max(0,x-frame.vision_radius);vx<=std::min(size.width-1,x+frame.vision_radius);++vx) {
              const Position unseen{vx,vy};
              if (memory_.cells()[MapMemory::index(unseen,size)]!=-1) continue;
              double competition=1;
              if (!visible.empty()) {
                int enemy_steps=size.width+size.height;
                for (const auto* e:visible) enemy_steps=std::min(enemy_steps,distance(e->position,unseen));
                const double margin=enemy_steps-steps-distance(p,unseen);
                const double probability=1/(1+std::exp(std::clamp(-margin/rw.explore_race_scale,-60.,60.)));
                const double available=rw.explore_capture_floor+(1-rw.explore_capture_floor)*probability;
                competition=(1-rw.explore_competition)+rw.explore_competition*available;
                competition*=1+rw.explore_urgency*std::exp(-std::abs(margin)/rw.explore_race_scale);
              }
              const int edge=std::min({vx,vy,size.width-1-vx,size.height-1-vy});
              gain+=unknown_supply[cell(unseen,size)]*competition*(1+rw.explore_edge_bonus/(1+edge));
            }
          const double density=gain/std::pow(steps+rw.explore_offset,rw.explore_distance_power)-
                               event_penalty(p,frame.tick+steps);
          if (density>best_density+1e-9) {best_density=density;observation=p;}
        }
        if (observation) {
          const planning::GridMap map{size.width,size.height,memory_.cells(),planning::RowOrder::BottomToTop};
          race_coverage_plan.route=planning::AStarPlanner{}.searchAStar(map,{start.x,start.y},
              {observation->x,observation->y},options);
        }
      }
      if (race_coverage_plan.route.success() && race_coverage_plan.route.path.size() > 1) {
        const auto at = race_coverage_plan.route.path.back();
        Candidate candidate{"explore", "race-cover", {at.x, at.y}};
        candidate.resource_race = true;
        candidate.information = information(candidate.position);
        candidate.utility = std::max(active_weights.resource_race.explore_move_priority * acquisition.exploration, candidate.information /
            (race_coverage_plan.route.cost + active_weights.travel_offset));
        resource_priority = candidate;
        plan_.resource_race["coverage"] = true;
      }
    }
    // 最晚必须启程的任务优先级仍兜底；不为慢慢走过去放弃即将超时的5分。
    if (resource_priority && (!active_weights.acquisition.enabled || resource_priority->kind=="resource" ||
        !best || resource_priority->utility>=best->utility) && !(deadline_mission &&
        remaining_ticks <= dist[cell(deadline_mission->position, size)] + active_weights.resource_race.task_deadline_buffer))
      best = resource_priority;
  }
  if(active_weights.purpose.enabled) {
    const auto& purpose=active_weights.purpose;
    std::string mode=search_gain>0?"explore":"finish";
    std::string reason="no_viable_battle_target";
    if(deadline_mission) {best=deadline_mission;mode="finish";reason="task_departure_deadline";}
    else if(purpose_resource&&(!best||purpose_resource->utility>=purpose.resource_floor*best->utility)) {
      best=purpose_resource;mode="collect";reason="positive_reachable_resource";
    } else if(!purpose_resource&&plan_.phase_resource_age>=purpose.resource_quiet_ticks&&
        purpose_battle&&(!best||purpose_battle->utility>=purpose.battle_floor*best->utility)) {
      best=purpose_battle;mode="battle";reason="no_current_resource_opportunity";
    } else if(purpose_resource)reason="resource_opportunity_cost_too_high";
    else if(plan_.phase_resource_age<purpose.resource_quiet_ticks)reason="resource_search_grace";
    plan_.purpose["mode"]=mode;
    plan_.purpose["reason"]=reason;
    plan_.purpose["resource_candidate"]=purpose_resource.has_value();
    plan_.purpose["resource_quiet_ticks"]=plan_.phase_resource_age;
    plan_.purpose["chase_spent"]=unproductive_pursuit_;
  }
  if (plan_.preserving_score && retreat_target && escape_steps <= remaining_ticks) {
    Candidate retreat{"evade", "endgame-preserve", *retreat_target};
    const double damage_loss =
        active_weights.damage_points / active_weights.damage_cap * std::min(60.0, frame.score.effective_damage);
    retreat.safety = active_weights.endgame_preserve_weight * (active_weights.death_cost + damage_loss);
    retreat.utility = retreat.safety / (escape_steps + active_weights.travel_offset);
    if (!best || retreat.utility > best->utility)
      best = retreat;
    ++plan_.candidates;
  }
  if (inside_danger) {
    std::optional<Position> exit;
    int exit_steps = std::numeric_limits<int>::max();
    for (int y = 0; y < size.height; ++y) {
      for (int x = 0; x < size.width; ++x) {
        const Position p{x, y};
        const int steps = dist[cell(p, size)];
        if (steps <= 0 || steps >= exit_steps || steps > remaining_ticks)
          continue;
        if (std::none_of(event_->dangerous_cells.begin(), event_->dangerous_cells.end(),
                         [&](Position danger) { return same(p, danger); })) {
          exit = p;
          exit_steps = steps;
        }
      }
    }
    // 预告期尚宽裕时保留正常策略；接近最后撤离时间后提高撤离优先级。
    if (exit && event_->begin_tick - frame.tick <= exit_steps + 2) {
      Candidate evacuation{"evade", "ai-danger-region", *exit};
      evacuation.safety = active_weights.death_cost * 2;
      evacuation.utility = evacuation.safety / (exit_steps + active_weights.travel_offset) + 0.01;
      best = evacuation;
      ++plan_.candidates;
    }
  }
  // 爆炸和世界分裂在移动前结算：必须在激活前按实际最短撤离步数预留时间。
  for (const auto& [id, e] : events_.effects()) {
    if (!e.actor.empty() || (e.kind != "explosion" && e.kind != "world_split") ||
        e.end_tick <= frame.tick || !Stage2Events::contains(e.cells, start))
      continue;
    if (e.kind == "explosion" && frame.self.spawn_protected && frame.tick >= e.begin_tick)
      continue;
    std::optional<Position> exit;
    int steps = std::numeric_limits<int>::max();
    for (int y = 0; y < size.height; ++y)
      for (int x = 0; x < size.width; ++x) {
        const Position p{x, y};
        const int d = dist[cell(p, size)];
        if (d > 0 && d < steps && !Stage2Events::contains(e.cells, p) && d <= remaining_ticks) {
          exit = p;
          steps = d;
        }
      }
    if (exit && e.begin_tick - frame.tick <= steps + active_weights.events.evacuation_buffer) {
      Candidate evacuate{"evade", id, *exit};
      evacuate.safety = active_weights.events.blast_risk;
      evacuate.utility = evacuate.safety / (steps + active_weights.travel_offset) + 0.01;
      if (!best || evacuate.utility > best->utility)
        best = evacuate;
    }
  }
  // 仅在确认无进展往返后选一个循环区域外的可达落点，所有攻防/事件风险仍由动作层比较。
  if(navigation_progress_.active()&&(!best||best->kind!="evade")&&
      (best||search_gain>0||current_damage_bound(false)>0)) {
    std::optional<Position> exit;double priority=std::numeric_limits<double>::infinity();
    for(int y=0;y<size.height;++y) for(int x=0;x<size.width;++x) {
      const Position p{x,y};const int steps=dist[cell(p,size)];
      if(steps<=0||steps>remaining_ticks||navigation_progress_.penalty(p,frame.tick,active_weights)>0) continue;
      int enemy_distance=0;
      if(!visible.empty()) {enemy_distance=size.width+size.height;for(const auto* e:visible) enemy_distance=std::min(enemy_distance,distance(p,e->position));}
      const double value=10*event_threats(p,visible)+steps-.3*information(p)-.05*enemy_distance+
          event_penalty(p,frame.tick+steps);
      if(value<priority) {priority=value;exit=p;}
    }
    if(exit) {
      Candidate escape{"unstick","navigation-progress",*exit};
      escape.safety=active_weights.navigation_cycle_cost;
      escape.utility=(best?best->utility:0)+active_weights.navigation_cycle_cost+.01;
      best=escape;
    }
  }
  if (best) {
    if(active_weights.purpose.enabled)plan_.purpose["selected_goal"]=best->kind;
    if (active_weights.resource_race.enabled) plan_.resource_race["selected"] = best->resource_race;
    plan_.goal = best->kind;
    plan_.target_id = best->id;
    plan_.target = best->position;
    plan_.event_reward = best->event_reward;
    plan_.resource_points = best->resource;
    plan_.mission_points = best->mission;
    plan_.combat_points = best->combat;
    plan_.information_points = best->information;
    plan_.observation_age_points = best->age_information;
    plan_.patrol_potential = best->patrol;
    plan_.safety_potential = best->safety;
    // 惯性用于稳定“去哪里”，不等于一步移动会获得的积分；否则高惯性会压过就地射击。
    plan_.goal_utility = best->utility -
        (active_weights.separate_goal_switch_bonus ? best->switch_bonus : 0.0);
    const planning::GridMap map{size.width, size.height, memory_.cells(),
                                planning::RowOrder::BottomToTop};
    plan_.joint_used = best->joint;
    plan_.joint_future_utility = best->future_utility;
    if (best->resource_race) {
      plan_.route = best->kind == "resource" ? resource_race_plan.route : race_coverage_plan.route;
    } else if (best->collection_search) {
      plan_.route=collection_search_plan.route;
    } else if (best->sweep) {
      plan_.route.status=planning::SearchStatus::Found;
      plan_.route.path=sweep_plan.path;
      plan_.route.cost=static_cast<int>(sweep_plan.path.size())-1;
    } else if (best->joint) {
      plan_.route = joint_plan.route;
      plan_.joint_visit_order = joint_plan.visit_order;
    } else {
      plan_.route = planning::AStarPlanner{}.searchAStar(
          map, {start.x, start.y}, {best->position.x, best->position.y}, options);
      if (weighted_event_route) {
        const auto safer = event_route(size, start, best->position, event_route_cost, passable);
        if (safer.success())
          plan_.route = safer;
      }
    }
  }

  const int incoming = frame.self.spawn_protected ? 0 : event_threats(start, visible);
  // 分期只降低开局主动攻击欲望；被动攻击风险、死亡边界和撤离逻辑完全沿用原判断。
  const double phase_attack_factor = phase == Stage2Phase::Collect
      ? active_weights.phase.opening_attack_factor : 1.0;
  plan_.incoming_damage_bound = current_damage_bound(false);
  // 交火线索只降低期望损伤，不降低攻击先结算的最坏致死边界。
  double expected_threats = incoming;
  if (use_intents && !frame.self.spawn_protected) {
    for (std::size_t i = 0; i < visible.size(); ++i)
      if (!visible[i]->spawn_protected.value_or(false) &&
          intent_clear_shot(visible[i]->position, start, intent_bodies, static_cast<int>(i)))
        expected_threats -=
            active_weights.third_party_risk_discount * intents.opponents[i].third_party_confidence;
    expected_threats = std::max(0.0, expected_threats);
  }
  double best_action = -std::numeric_limits<double>::infinity();
  const bool urgent_own_goal=best&&(best->kind=="evade"||
      (best->resource+best->mission)>0);
  const auto interference_gain=[&](const VisibleEntity& enemy,double banked_damage=0.0) {
    if(frame.score.effective_damage<active_weights.damage_cap) return 0.0;
    double reflection=0;
    if(purity) {
      if(own_unrivaled) {
        for(const auto* target:visible)
          if(!target->spawn_protected.value_or(false)&&
             square_hit(start,target->position,own_unrivaled->effect.attack_radius))
            reflection+=purity->reflection_damage;
      } else reflection=purity->reflection_damage;
    }
    return active_weights.interference.attack_value(frame.score.effective_damage+banked_damage,active_weights.damage_cap,
        active_weights.damage_points,frame.self.hp,current_damage_bound(false)+reflection,
        enemy.hp.value_or(100.0),estimated_damage(enemy),urgent_own_goal);
  };
  /// 每项动作都承担当前位置的本Tick攻击风险；移动只能改变后续暴露，不能回避先结算的攻击。
  const auto evaluate = [&](Action action, Position destination, double gain, double interference=0.0) {
    double bound = current_damage_bound(action.type == "defend");
    // 高采集权重不许诺攻击先结算时无法执行的移动；防御能活下来时撤回该移动收益。
    if (active_weights.acquisition.enabled && action.type=="move" && bound>=frame.self.hp &&
        current_damage_bound(true)<frame.self.hp)
      gain=0;
    double reflected_expected = 0, reflected_bound = 0;
    if (purity && action.type == "attack") {
      for (std::size_t i = 0; i < kDirections.size(); ++i)
        if (action.direction == kDirections[i]) {
          const auto* ordinary = own_unrivaled ? nullptr : attack_target(start, kSteps[i], visible);
          for (const auto* target : visible)
            if (!target->spawn_protected.value_or(false) &&
                (own_unrivaled
                     ? square_hit(start, target->position, own_unrivaled->effect.attack_radius)
                     : target == ordinary)) {
              reflected_expected += purity->reflection_damage * defend_probability(*target);
              reflected_bound += purity->reflection_damage;
            }
        }
      bound += reflected_bound;
    }
    const double hp_risk =
        1.0 + active_weights.low_hp_risk_weight * std::clamp(1.0 - frame.self.hp / 100.0, 0.0, 1.0);
    const double expected_bound =
        incoming > 0 ? current_damage_bound(action.type == "defend") * expected_threats / incoming
                     : 0.0;
    double utility =
        gain + interference + hold_reward(destination) -
        expected_bound * active_weights.attack_probability * active_weights.hp_loss_cost * hp_risk -
        reflected_expected * active_weights.hp_loss_cost * hp_risk;
    if(action.type=="move")
      utility-=navigation_progress_.penalty(destination,frame.tick,active_weights);
    utility -= event_penalty(destination, frame.tick + 1, action.type == "move");
    if (action.type == "defend" && purity)
      utility += purity->reflection_damage * active_weights.events.purity_defense_value *
                 expected_threats * active_weights.attack_probability;
    const auto healing = events_.buff(frame.self.team, "angel", frame.tick);
    if (healing && bound < frame.self.hp)
      utility +=
          std::min(healing->effect.heal_per_tick, expected_bound * active_weights.attack_probability) *
          active_weights.hp_loss_cost;
    if (bound > 0 && frame.self.hp <= bound) {
      const double damage_loss = active_weights.damage_points / active_weights.damage_cap *
                                 std::min(60.0, frame.score.effective_damage);
      utility -= active_weights.death_cost + damage_loss;
    }
    const bool retains_protection = frame.self.spawn_protected && same(start, destination);
    if (!retains_protection) {
      double exposure =
          (1.0 - active_weights.opponent_motion_weight) * event_threats(destination, visible) +
          active_weights.opponent_motion_weight * event_threats(destination, projected);
      if (active_weights.intent_risk_weight > 0)
        exposure = (1.0 - active_weights.intent_risk_weight) * exposure +
                   active_weights.intent_risk_weight * intents.exposure[cell(destination, size)];
      double future_multiplier = multiplier(frame.self.team);
      const auto pan = events_.active("pan", frame.tick);
      if (action.type == "move" && pan && frame.tick < pan->begin_tick + pan->movement_window_ticks)
        future_multiplier = std::max(future_multiplier, 1.0 + active_weights.events.vulnerability_risk *
                                                                  (pan->damage_multiplier - 1.0));
      utility -= exposure * future_multiplier * active_weights.future_exposure_cost * hp_risk *
                 (plan_.preserving_score ? 1.0 + active_weights.endgame_preserve_weight : 1.0);
      utility-=active_weights.combat_clue_weight*battle_evidence_.exposure(destination)*
          active_weights.future_exposure_cost*hp_risk;
    }
    if (avoid_event && event_->begin_tick <= frame.tick &&
        std::any_of(event_->dangerous_cells.begin(), event_->dangerous_cells.end(),
                    [&](Position p) { return same(p, destination); }))
      utility -= active_weights.death_cost * 2;
    plan_.action_scores.push_back({{"action", action.type},
                                   {"direction", action.direction},
                                   {"utility", utility},
                                   {"interference_utility", interference},
                                   {"incoming_bound", bound}});
    if (utility > best_action + 1e-9) {
      best_action = utility;
      cached_ = std::move(action);
    }
  };
  // 无目标时先WAIT；其余动作必须有正的收益或安全改善才覆盖它，避免无意义游走。
  evaluate(Action::wait(), start, 0);
  // 只在资源/任务/开图的普通最短路上比较沿途观察；不改变联合路线顺序与战斗目标。
  const bool observe_route =
      active_weights.route_information_weight > 0 && best && !best->joint &&
      (best->kind == "resource" || best->kind == "mission" || best->kind == "explore");
  const auto step_information = [&](Position p) {
    return observe_route
               ? active_weights.route_information_weight * information(p) / (1.0 + active_weights.travel_offset)
               : 0.0;
  };
  if (plan_.route.success() && plan_.route.path.size() > 1) {
    const auto next = plan_.route.path[1];
    for (std::size_t i = 0; i < kSteps.size(); ++i) {
      if (next.x == start.x + kSteps[i].x && next.y == start.y + kSteps[i].y) {
        evaluate(Action::move(kDirections[i]), {next.x, next.y},
                 plan_.goal_utility + step_information({next.x, next.y}));
        break;
      }
    }
  }
  // 反向距离场让所有同样接近目标的首步获得收益，再由当前/未来风险择优。
  // 联合采集路线保持原访问顺序，不能用捷径跳过途中计划采集的资源。
  std::vector<int> goal_distances;
  if ((active_weights.route_alternatives_weight > 0 || observe_route) && best && !best->joint &&
      plan_.route.success() && plan_.route.path.size() > 1)
    goal_distances = goal_distance_field(size, best->position, passable);
  // 即使目标路线当前危险，也保留其他合法侧移作为局部避险候选。
  for (std::size_t i = 0; i < kSteps.size(); ++i) {
    Position p{start.x + kSteps[i].x, start.y + kSteps[i].y};
    if (passable(p)) {
      double gain = -0.01;
      if (!goal_distances.empty() && goal_distances[cell(start, size)] >= 0 &&
          goal_distances[cell(p, size)] >= 0) {
        const int progress = goal_distances[cell(start, size)] - goal_distances[cell(p, size)];
        gain += active_weights.route_alternatives_weight * plan_.goal_utility * progress;
        if (observe_route && progress == 1)
          gain = std::max(gain, plan_.goal_utility + step_information(p));
      }
      evaluate(Action::move(kDirections[i]), p, gain);
    }
  }
  if (!frame.self.spawn_protected && own_unrivaled) {
    double damage = 0;
    double interference=0;
    bool target = false;
    for (const auto* enemy : visible)
      if (!enemy->spawn_protected.value_or(false) &&
          square_hit(start, enemy->position, own_unrivaled->effect.attack_radius)) {
        target = true;
        interference+=interference_gain(*enemy,damage);
        damage += estimated_damage(*enemy);
      }
    if (target)
      evaluate({"attack", "up"}, start, damage_gain(frame, active_weights, damage) * combat_weight *
               phase_attack_factor,interference);
  }
  if (!frame.self.spawn_protected && !own_unrivaled) {
    for (std::size_t i = 0; i < kSteps.size(); ++i) {
      const auto* target = attack_target(start, kSteps[i], visible);
      if (target && !target->spawn_protected.value_or(false)) {
        const auto index = static_cast<std::size_t>(
            std::find(visible.begin(), visible.end(), target) - visible.begin());
        const double opportunity = use_intents
                                       ? 1.0 + active_weights.third_party_attack_bonus *
                                                   intents.opponents[index].third_party_confidence
                                       : 1.0;
        evaluate({"attack", kDirections[i]}, start,
                 event_attack_gain(*target) * combat_weight * opportunity * phase_attack_factor,
                 interference_gain(*target));
      }
    }
  }
  evaluate({"defend", ""}, start, 0);
  const bool preserve_collection = active_weights.rollout.preserve_collection &&
                                   (plan_.goal == "resource" || plan_.goal == "mission") &&
                                   current_damage_bound(false) <= 0;
  if (active_weights.rollout.weight > 0 && !visible.empty() && !preserve_collection) {
    std::vector<RolloutRoot> roots;
    for (const auto& score : plan_.action_scores)
      roots.push_back(
          {{score.at("action").get<std::string>(), score.at("direction").get<std::string>()},
           score.at("utility").get<double>()});
    std::vector<int> rollout_distances;
    if (best)
      rollout_distances = goal_distance_field(size, best->position, [&](Position p) {
        return inside(p, size) && memory_.cells()[MapMemory::index(p, size)] == 0;
      });
    const auto rollout = tactical_rollout(frame, memory_, events_, old, active_weights, active_weights.rollout,
                                          roots, cached_, rollout_distances, plan_.goal_utility,
                                          normal_collected_, high_collected_, remaining_ticks);
    plan_.rollout = {{"ran", rollout.ran},
                     {"changed", rollout.changed},
                     {"completed_depth", rollout.completed_depth},
                     {"transitions", rollout.transitions},
                     {"elapsed_ms", rollout.elapsed_ms},
                     {"budget_hit", rollout.budget_hit},
                     {"roots", rollout.roots}};
    if (rollout.ran && rollout.completed_depth >= 2) {
      cached_ = rollout.action;
      best_action = rollout.utility;
    }
  }
  physical_cached_ = cached_;
  for(const auto& score:plan_.action_scores)
    if(score.at("action")==cached_.type&&score.at("direction")==cached_.direction)
      plan_.interference_utility=score.value("interference_utility",0.0);
  if (cached_.type == "move" && events_.buff(frame.self.team, "illusion", frame.tick)) {
    plan_.movement_inverted = true;
    if (cached_.direction == "up")
      cached_.direction = "down";
    else if (cached_.direction == "down")
      cached_.direction = "up";
    else if (cached_.direction == "left")
      cached_.direction = "right";
    else if (cached_.direction == "right")
      cached_.direction = "left";
  }
  plan_.action_utility = best_action;
  previous_goal_ = best ? best->kind + ":" + best->id : "";
  return cached_;
}

}  // namespace rmtc
