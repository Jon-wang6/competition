/** @file stage2_neural.cpp
 * @brief 固定结构MLP的C++前向传播和模型校验；不连接HTTP，不修改原策略参数。
 */
#include "rmtc_connection/stage2_neural.hpp"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <random>
#include <stdexcept>

namespace rmtc {
void NeuralWeights::validate() const {
  for (double v : {weight, max_correction, override_margin, teacher_budget_ms})
    if (!std::isfinite(v) || v < 0)
      throw std::invalid_argument("invalid neural weight");
  if (weight > 2 || max_correction > 3 || override_margin > 1 || sample_stride < 1 ||
      sample_stride > 100 || teacher_horizon < 2 || teacher_horizon > 7 || teacher_budget_ms < 1 ||
      teacher_budget_ms > 150 || (enabled && model_file.empty()) ||
      (collect && sample_file.empty()))
    throw std::invalid_argument("invalid neural paths/budget");
}

const std::array<const char*, kNeuralInputs>& neural_feature_names() {
  static const std::array<const char*, kNeuralInputs> names{{"tick_fraction",
                                                             "own_hp",
                                                             "damage_fraction",
                                                             "resource_fraction",
                                                             "map_coverage",
                                                             "resource_goal",
                                                             "explore_goal",
                                                             "mission_goal",
                                                             "combat_goal",
                                                             "evade_goal",
                                                             "local_action_score",
                                                             "baseline_action_score",
                                                             "goal_score",
                                                             "resource_score",
                                                             "mission_score",
                                                             "combat_score",
                                                             "information_score",
                                                             "patrol_score",
                                                             "visible_enemy_count",
                                                             "nearest_enemy_distance",
                                                             "incoming_damage_bound",
                                                             "destination_threat",
                                                             "destination_event_risk",
                                                             "goal_progress",
                                                             "blocked_streak",
                                                             "wait_action",
                                                             "move_action",
                                                             "attack_action",
                                                             "defend_action",
                                                             "move_dx",
                                                             "move_dy",
                                                             "spawn_protected"}};
  return names;
}

TinyNeuralNetwork::TinyNeuralNetwork(unsigned seed) : parameters_(kNeuralParameters, 0) {
  std::mt19937 rng(seed);
  std::normal_distribution<float> first(0, std::sqrt(2.0F / kNeuralInputs));
  std::normal_distribution<float> second(0, std::sqrt(2.0F / kNeuralHidden1));
  for (int i = 0; i < kNeuralInputs * kNeuralHidden1; ++i)
    parameters_[i] = first(rng);
  const int offset = kNeuralInputs * kNeuralHidden1 + kNeuralHidden1;
  for (int i = 0; i < kNeuralHidden1 * kNeuralHidden2; ++i)
    parameters_[offset + i] = second(rng);
}

float TinyNeuralNetwork::predict(const NeuralFeatures& input) const {
  for (float v : input)
    if (!std::isfinite(v))
      throw std::runtime_error("nonfinite neural input");
  std::array<float, kNeuralHidden1> h1{};
  std::array<float, kNeuralHidden2> h2{};
  const int b1 = kNeuralInputs * kNeuralHidden1;
  const int w2 = b1 + kNeuralHidden1, b2 = w2 + kNeuralHidden1 * kNeuralHidden2,
            w3 = b2 + kNeuralHidden2;
  for (int j = 0; j < kNeuralHidden1; ++j) {
    float v = parameters_[b1 + j];
    for (int i = 0; i < kNeuralInputs; ++i)
      v += parameters_[j * kNeuralInputs + i] * input[i];
    h1[j] = std::max(0.0F, v);
  }
  for (int j = 0; j < kNeuralHidden2; ++j) {
    float v = parameters_[b2 + j];
    for (int i = 0; i < kNeuralHidden1; ++i)
      v += parameters_[w2 + j * kNeuralHidden1 + i] * h1[i];
    h2[j] = std::max(0.0F, v);
  }
  float out = parameters_.back();
  for (int i = 0; i < kNeuralHidden2; ++i)
    out += parameters_[w3 + i] * h2[i];
  if (!std::isfinite(out))
    throw std::runtime_error("nonfinite neural output");
  return out;
}

void TinyNeuralNetwork::load(const std::string& path) {
  if (std::filesystem::file_size(path) > 1024 * 1024)
    throw std::runtime_error("neural model too large");
  std::ifstream stream(path);
  nlohmann::json data;
  stream >> data;
  if (data.at("format") != "rmtc_residual_mlp_v1" ||
      data.at("architecture") != nlohmann::json::array({32, 64, 32, 1}) ||
      data.at("features") != nlohmann::json(neural_feature_names()))
    throw std::runtime_error("incompatible neural model/features");
  auto weights = data.at("parameters").get<std::vector<float>>();
  if (weights.size() != kNeuralParameters)
    throw std::runtime_error("invalid neural parameter count");
  for (float v : weights)
    if (!std::isfinite(v) || std::abs(v) > 100)
      throw std::runtime_error("invalid neural parameter");
  parameters_ = std::move(weights);
}

void TinyNeuralNetwork::save(const std::string& path, const nlohmann::json& metadata) const {
  const std::filesystem::path target(path);
  if (!target.parent_path().empty())
    std::filesystem::create_directories(target.parent_path());
  std::ofstream stream(path);
  stream.exceptions(std::ios::failbit | std::ios::badbit);
  stream << nlohmann::json{{"format", "rmtc_residual_mlp_v1"},
                           {"architecture", {32, 64, 32, 1}},
                           {"features", neural_feature_names()},
                           {"parameters", parameters_},
                           {"training", metadata}}
                .dump(2)
         << '\n';
}
}  // namespace rmtc
