/**
 * @file train_stage2_neural.cpp
 * @brief 纯C++反向传播训练；按整张地图划分训练/验证，保存模型和逐轮真实指标。
 * 训练标签是更深公开信息推演的评分差，不是真实最优解或正式比赛分数。
 */
#include "neural_training.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <random>
#include <set>

namespace {
using Json = nlohmann::json;
using Path = std::filesystem::path;
using namespace rmtc::training;
/// 根据地图种子分组，同一图的四种出生和所有Tick只能进入同一数据分区。
bool validation_group(const std::string& group) {
  if (group.empty())
    throw std::runtime_error("sample missing map group");
  return std::stoll(group) % 5 == 0;
}
/// 读取C++采样文件，保留公开特征和教师残差，校验维度、有限值及取值范围。
void load(const Path& root, std::vector<Sample>& train, std::vector<Sample>& validation,
          std::set<std::string>& groups) {
  std::vector<Path> files;
  for (const auto& entry : std::filesystem::recursive_directory_iterator(root))
    if (entry.path().filename() == "teacher.jsonl" &&
        std::filesystem::exists(entry.path().parent_path() / "result.json"))
      files.push_back(entry.path());
  std::sort(files.begin(), files.end());
  for (const auto& path : files) {
    std::ifstream stream(path);
    std::string line;
    while (std::getline(stream, line)) {
      if (line.empty())
        continue;
      const auto row = Json::parse(line);
      const auto group = row.at("group").get<std::string>();
      groups.insert(group);
      const auto state =
          row.at("session_id").get<std::string>() + ":" + std::to_string(row.at("tick").get<int>());
      double best_base = -1e30, best_teacher = -1e30, baseline_teacher = 0;
      for (const auto& value : row.at("samples")) {
        const double b = value.at("baseline"), t = b + value.at("target").get<double>();
        best_teacher = std::max(best_teacher, t);
        if (b > best_base) {
          best_base = b;
          baseline_teacher = t;
        }
      }
      for (const auto& value : row.at("samples")) {
        Sample s;
        s.features = value.at("features").get<rmtc::NeuralFeatures>();
        s.target = value.at("target");
        s.baseline = value.at("baseline");
        s.state = state;
        s.group = group;
        s.importance = (s.baseline >= best_base - .5 ? 1.F : .2F) *
                       (best_teacher - baseline_teacher > .02 ? 5.F : 1.F);
        for (float v : s.features)
          if (!std::isfinite(v) || std::abs(v) > 1.001)
            throw std::runtime_error("invalid normalized neural feature");
        if (!std::isfinite(s.target) || !std::isfinite(s.baseline))
          throw std::runtime_error("nonfinite sample label");
        (validation_group(group) ? validation : train).push_back(std::move(s));
      }
    }
  }
}
/** @brief 测量未训练/已训练网络的误差及教师动作一致率；不把离线准确率称为胜率。 */
Json evaluate(const rmtc::TinyNeuralNetwork& model, const std::vector<Sample>& data) {
  double loss = 0, zero = 0, regret = 0;
  int states = 0, correct = 0, baseline_correct = 0;
  struct Choice {
    float teacher = -1e30F, base = -1e30F, pred = -1e30F;
    float chosen_teacher = 0, base_teacher = 0;
  };
  std::map<std::string, Choice> choices;
  for (const auto& s : data) {
    const float p = model.predict(s.features), t = s.baseline + s.target;
    loss += (p - s.target) * (p - s.target);
    zero += s.target * s.target;
    auto& c = choices[s.state];
    c.teacher = std::max(c.teacher, t);
    if (s.baseline > c.base) {
      c.base = s.baseline;
      c.base_teacher = t;
    }
    if (s.baseline + p > c.pred) {
      c.pred = s.baseline + p;
      c.chosen_teacher = t;
    }
  }
  for (const auto& [key, c] : choices) {
    (void)key;
    ++states;
    correct += c.chosen_teacher >= c.teacher - .001F;
    baseline_correct += c.base_teacher >= c.teacher - .001F;
    regret += c.teacher - c.chosen_teacher;
  }
  return {{"samples", data.size()},
          {"states", states},
          {"mse", loss / data.size()},
          {"zero_network_mse", zero / data.size()},
          {"teacher_action_agreement", double(correct) / states},
          {"baseline_teacher_agreement", double(baseline_correct) / states},
          {"teacher_regret", regret / states}};
}
}  // namespace

/** @brief 加载样本、执行小批次Adam、每轮输出验证变化，保留最佳和各5轮检查点。 */
int main(int argc, char** argv) {
  try {
    std::map<std::string, std::string> args;
    for (int i = 1; i + 1 < argc; i += 2)
      args[argv[i]] = argv[i + 1];
    if (args.count("--zero-output")) {
      rmtc::TinyNeuralNetwork{}.save(args["--zero-output"]);
      return 0;
    }
    const Path input = args.at("--data"), output = args.at("--output");
    const int epochs = args.count("--epochs") ? std::stoi(args["--epochs"]) : 30;
    const int seed = args.count("--seed") ? std::stoi(args["--seed"]) : 42,
              batch = args.count("--batch") ? std::stoi(args["--batch"]) : 256;
    const float rate = args.count("--rate") ? std::stof(args["--rate"]) : .001F;
    const bool pairwise = args.count("--pairwise") && args["--pairwise"] == "true";
    const bool invariant =
        args.count("--rotation-invariant") && args["--rotation-invariant"] == "true";
    if (epochs < 1 || epochs > 1000 || batch < 2 || batch > 4096 || rate <= 0 || rate > .1)
      throw std::runtime_error("invalid training limits");
    std::filesystem::create_directories(output.parent_path());
    Eigen::setNbThreads(1);
    std::vector<Sample> train, validation;
    std::set<std::string> groups;
    load(input, train, validation, groups);
    if (train.size() < 100 || validation.size() < 50)
      throw std::runtime_error("insufficient independent training/validation samples");
    rmtc::TinyNeuralNetwork model(seed);
    Adam adam;
    if (args.count("--resume")) {
      model.load(args["--resume"]);
      const auto state = Path(args["--resume"] + ".optimizer.json");
      if (std::filesystem::exists(state)) {
        std::ifstream s(state);
        Json j;
        s >> j;
        adam.first = j.at("first").get<std::vector<float>>();
        adam.second = j.at("second").get<std::vector<float>>();
        adam.steps = j.at("steps");
        if (adam.first.size() != rmtc::kNeuralParameters ||
            adam.second.size() != rmtc::kNeuralParameters)
          throw std::runtime_error("incompatible optimizer");
      }
    }
    std::vector<Pair> pairs;
    if (pairwise) {
      std::map<std::string, std::vector<std::size_t>> states;
      for (std::size_t i = 0; i < train.size(); ++i)
        states[train[i].state].push_back(i);
      for (const auto& [key, indices] : states) {
        (void)key;
        auto good = indices.front();
        float best_base = -1e30;
        for (auto i : indices) {
          best_base = std::max(best_base, train[i].baseline);
          if (train[i].baseline + train[i].target > train[good].baseline + train[good].target)
            good = i;
        }
        for (auto i : indices)
          if (i != good && train[i].baseline >= best_base - .5)
            pairs.push_back({good, i});
      }
    }
    if (invariant)
      for (int row = 0; row < 64; ++row)
        for (int col : {29, 30})
          model.parameters()[row * 32 + col] = 0;
    std::vector<std::size_t> order(pairwise ? pairs.size() : train.size());
    std::iota(order.begin(), order.end(), 0);
    std::mt19937 rng(seed);
    Json history = Json::array();
    const auto before = evaluate(model, validation);
    double best = std::numeric_limits<double>::infinity(), best_policy = best;
    const auto began = std::chrono::steady_clock::now();
    std::cout << Json{{"epoch", 0},
                      {"train_samples", train.size()},
                      {"validation", before},
                      {"map_groups", groups.size()},
                      {"parameter_count", rmtc::kNeuralParameters}}
                     .dump()
              << std::endl;
    for (int epoch = 1; epoch <= epochs; ++epoch) {
      std::shuffle(order.begin(), order.end(), rng);
      for (std::size_t offset = 0; offset < order.size(); offset += batch) {
        const auto count = std::min<std::size_t>(batch, order.size() - offset);
        auto g = pairwise ? pairwise_gradient(model, train, pairs, order, offset, count)
                          : gradient(model, train, order, offset, count);
        if (invariant)
          for (int row = 0; row < 64; ++row)
            for (int col : {29, 30})
              g.values[row * 32 + col] = 0;
        adam.update(model, g, rate);
        if (invariant)
          for (int row = 0; row < 64; ++row)
            for (int col : {29, 30})
              model.parameters()[row * 32 + col] = 0;
      }
      const auto checked = evaluate(model, validation);
      Json row{{"epoch", epoch},
               {"validation", checked},
               {"train", evaluate(model, train)},
               {"seconds",
                std::chrono::duration<double>(std::chrono::steady_clock::now() - began).count()}};
      history.push_back(row);
      std::cout << row.dump() << std::endl;
      const Json metadata{
          {"method", pairwise ? "pairwise deeper-rollout residual; Adam backpropagation"
                              : "supervised deeper-rollout residual; Adam backpropagation"},
          {"rotation_invariant", invariant},
          {"training_pairs", pairs.size()},
          {"seed", seed},
          {"epoch", epoch},
          {"dataset", std::filesystem::absolute(input).string()},
          {"map_groups", groups},
          {"train_samples", train.size()},
          {"validation_samples", validation.size()},
          {"split", "map seed modulo 5; remainder 0 held out"},
          {"metrics", row},
          {"official_ai_qualification", false}};
      if (checked.at("mse").get<double>() < best) {
        best = checked.at("mse");
        model.save(output.string(), metadata);
        std::ofstream state(output.string() + ".optimizer.json");
        state << Json{{"steps", adam.steps}, {"first", adam.first}, {"second", adam.second}}.dump();
      }
      if (checked.at("teacher_regret").get<double>() < best_policy) {
        best_policy = checked.at("teacher_regret");
        model.save(output.string() + ".policy.json", metadata);
        std::ofstream state(output.string() + ".policy.json.optimizer.json");
        state << Json{{"steps", adam.steps}, {"first", adam.first}, {"second", adam.second}}.dump();
      }
      if (epoch % 5 == 0)
        model.save(output.string() + ".epoch-" + std::to_string(epoch) + ".json", metadata);
      std::ofstream report(output.string() + ".training.json");
      report << Json{{"before", before}, {"epochs", history}, {"best_validation_mse", best}}.dump(2)
             << '\n';
    }
    return 0;
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
