/** @file stage2_neural_policy_test.cpp
 * @brief 验证零网络/只采样时动作不变，以及网络不能新增当前已知致死动作。
 */
#include "rmtc_connection/stage2_strategy.hpp"
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

/// 业务断言，不随Release优化而省略。
void require(bool value, const char* message) {
  if (!value)
    throw std::runtime_error(message);
}
/// 构造公开可见的一对一场景，不提供隐藏地形或对手指令。
rmtc::PublicPerception perception(int tick, double hp = 100) {
  rmtc::PublicPerception p;
  p.session_id = "neural-policy-test";
  p.tick = tick;
  p.map = {9, 9};
  p.vision_radius = 4;
  p.self.team = "A";
  p.self.alive = true;
  p.self.hp = hp;
  p.self.position = {4, 4};
  rmtc::VisibleEntity e;
  e.type = "robot";
  e.team = "B";
  e.id = "B";
  e.position = {4, 5};
  e.hp = 100;
  e.spawn_protected = false;
  e.defending = false;
  p.visible_entities = {e};
  return p;
}
/** @brief 使用真实策略流程检查模型开关、教师副作用与安全过滤；仅写本测试临时目录。 */
int main() {
  const auto dir =
      std::filesystem::temp_directory_path() / ("rmtc-neural-policy-" + std::to_string(getpid()));
  try {
    std::filesystem::create_directories(dir);
    const auto model = (dir / "zero.json").string();
    rmtc::TinyNeuralNetwork zero;
    zero.save(model);
    rmtc::Stage2Weights w;
    w.rollout.weight = 0;
    auto n = w;
    n.neural.enabled = true;
    n.neural.model_file = model;
    auto t = w;
    t.neural.collect = true;
    t.neural.sample_file = (dir / "samples.jsonl").string();
    t.neural.sample_group = "100";
    t.neural.teacher_horizon = 3;
    t.neural.sample_stride = 1;
    rmtc::Stage2Strategy base(w), neural(n), teacher(t);
    for (int tick = 100; tick < 108; ++tick) {
      const auto p = perception(tick);
      const auto a = base.decide(p), b = neural.decide(p), c = teacher.decide(p);
      require(a.type == b.type && a.direction == b.direction,
              "zero residual changed baseline action");
      require(a.type == c.type && a.direction == c.direction,
              "collecting labels changed executed action");
    }
    auto& values = zero.parameters();
    std::fill(values.begin(), values.end(), 0);
    values[27] = 1;
    values[2112] = 1;
    values[4192] = 50;
    const auto aggressive = (dir / "aggressive.json").string();
    zero.save(aggressive);
    n.neural.model_file = aggressive;
    n.neural.weight = 2;
    n.neural.max_correction = 3;
    rmtc::Stage2Strategy safe(n);
    const auto action = safe.decide(perception(120, 15));
    require(action.type == "defend",
            "neural correction overrode a surviving defense with a lethal action");
    std::filesystem::remove_all(dir);
    std::cout << "neural off/zero/teacher equivalence and lethal bound passed\n";
    return 0;
  } catch (const std::exception& e) {
    std::filesystem::remove_all(dir);
    std::cerr << e.what() << '\n';
    return 1;
  }
}
