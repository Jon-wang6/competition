/**
 * @file stage2_planning.cpp
 * @brief 固定节点预算的滚动采集规划；正式封顶积分、任务完成与探索机会分别记账。
 */
#include "rmtc_connection/stage2_planning.hpp"
#include "rmtc_connection/stage2_config.hpp"
#include "rmtc_connection/stage2_collection.hpp"
#include <algorithm>
#include <bitset>
#include <chrono>
#include <cmath>
#include <limits>
#include <map>
#include <queue>
#include <stdexcept>
#include <tuple>

namespace rmtc {
void PlanningWeights::validate() const {
  for (double x : {budget_ms,discount,terminal_weight,memory_half_life,enemy_pressure,
                   exploration_floor,route_tie_margin,future_risk_weight})
    if (!std::isfinite(x) || x < 0) throw std::invalid_argument("invalid planning weight");
  if (horizon<1 || horizon>32 || beam_width<1 || beam_width>64 || max_nodes<5 ||
      max_nodes>100000 || budget_ms<=0 || budget_ms>100 || discount<=0 || discount>1 ||
      terminal_weight>1 || memory_half_life<=0 || exploration_floor>1)
    throw std::invalid_argument("invalid planning budget or probability scale");
}

double planning_damage_loss(double damage,double cap,double points,double deduction) {
  const auto score=[&](double d) {return points*std::clamp(d/cap,0.0,1.0);};
  return score(damage)-score(std::max(0.0,damage-deduction));
}

double planning_resource_presence(int age,int enemy_steps,const PlanningWeights& w) {
  const double pressure=enemy_steps<0?0.0:w.enemy_pressure/(1.0+enemy_steps);
  return std::exp2(-std::max(0,age)*(1.0+pressure)/w.memory_half_life);
}

Json PlanningResult::describe() const {
  Json rows=Json::array();
  constexpr std::array<const char*,5> names{{"wait","up","down","left","right"}};
  for(std::size_t i=0;i<roots.size();++i) if(roots[i].valid) {
    const auto& r=roots[i];Json path=Json::array();
    for(const auto p:r.path) path.push_back({p.x,p.y});
    rows.push_back({{"root",names[i]},{"value",r.value},{"resource_points",r.resource_points},
        {"mission_points",r.mission_points},{"information",r.information},
        {"terminal",r.terminal},{"path",std::move(path)}});
  }
  return {{"ran",ran},{"useful",useful},{"completed_depth",completed_depth},
      {"expanded",expanded},{"budget_hit",budget_hit},{"elapsed_ms",elapsed_ms},
      {"resources",resources},{"roots",std::move(rows)},
      {"confidence_is_calibrated_probability",false}};
}

PlanningResult plan_collection_actions(
    const PublicPerception& f,const MapMemory& memory,const Stage2Weights& w,
    int remaining,int normal_collected,int high_collected,double resource_weight,
    double mission_weight,const std::vector<int>& enemy_steps,
    const std::function<bool(Position,int)>& passable,
    const std::function<double(double,double)>& information,
    const std::function<double(Position,int)>& future_risk,
    const std::vector<double>& supply,std::optional<Position> exploration_target,
    const std::vector<Position>& original_path) {
  PlanningResult result;
  if(!w.planning.enabled || remaining<=0) return result;
  const auto began=std::chrono::steady_clock::now();
  const auto elapsed=[&] {return std::chrono::duration<double,std::milli>(
      std::chrono::steady_clock::now()-began).count();};
  const auto finish=[&] {result.elapsed_ms=elapsed();return result;};
  const int width=f.map.width,height=f.map.height,count=width*height;
  if(count<=0 || count>1024 || enemy_steps.size()!=static_cast<std::size_t>(count) ||
      memory.cells().size()!=static_cast<std::size_t>(count) ||
      (!supply.empty()&&supply.size()!=static_cast<std::size_t>(count))) return finish();
  result.ran=true;
  const int horizon=std::min(remaining,w.planning.horizon);
  constexpr std::array<Position,5> deltas{{{0,0},{0,-1},{0,1},{-1,0},{1,0}}};
  const auto inside=[&](Position p) {return p.x>=0&&p.x<width&&p.y>=0&&p.y<height;};
  if(!inside(f.self.position))return finish();
  const auto index=[&](Position p) {return p.y*width+p.x;};
  const auto position=[&](int i) {return Position{i%width,i/width};};
  /// 静态距离只用于窗口外估计；真实展开的每一步仍检查该Tick的临时墙体。
  const auto field=[&](Position goal) {
    std::vector<int> distances(count,-1);std::queue<Position> pending;
    if(!inside(goal)) return distances;
    distances[index(goal)]=0;pending.push(goal);
    while(!pending.empty()) {
      const auto p=pending.front();pending.pop();
      for(std::size_t i=1;i<deltas.size();++i) {
        const Position q{p.x+deltas[i].x,p.y+deltas[i].y};
        if(!inside(q)||distances[index(q)]>=0||memory.cells()[MapMemory::index(q,f.map)]!=0) continue;
        distances[index(q)]=distances[index(p)]+1;pending.push(q);
      }
    }
    return distances;
  };
  struct Resource {Position at;double value,presence,preference;bool high;int enemy;std::vector<int> distances;};
  std::vector<Resource> resources;
  for(const auto& [key,m]:memory.entities()) {
    const auto& e=m.entity;
    if(resources.size()>=16) break;
    if(m.first_missing_tick || !e.value || *e.value<=0 || !inside(e.position) ||
       (e.type!="resource_normal"&&e.type!="resource_high")) continue;
    const int enemy=enemy_steps[index(e.position)];
    const int age=static_cast<int>(std::max<std::int64_t>(0,f.tick-m.last_seen_tick));
    const double presence=planning_resource_presence(age,enemy,w.planning);
    resources.push_back({e.position,*e.value,presence,age==0?w.visible_resource_weight:1.0,
        e.type=="resource_high",enemy,field(e.position)});
    result.resources.push_back({{"id",e.id.value_or(key)},{"age_ticks",age},
        {"presence_estimate",presence},{"enemy_steps",enemy}});
  }
  const auto exploration_distances=exploration_target?field(*exploration_target):std::vector<int>{};
  std::vector<std::bitset<1024>> views(count);
  std::vector<double> edges(count),supplies(count);
  for(int i=0;i<count;++i) {
    if((i&63)==0&&elapsed()>=w.planning.budget_ms) {result.budget_hit=true;return finish();}
    const auto p=position(i);
    edges[i]=1+w.edge_information_bonus/(1.0+std::min({p.x,p.y,width-1-p.x,height-1-p.y}));
    supplies[i]=supply.empty()?1.0:supply[i];
    if(memory.cells()[MapMemory::index(p,f.map)]!=0) continue;
    for(int y=std::max(0,p.y-f.vision_radius);y<=std::min(height-1,p.y+f.vision_radius);++y)
      for(int x=std::max(0,p.x-f.vision_radius);x<=std::min(width-1,p.x+f.vision_radius);++x)
        if(memory.cells()[MapMemory::index({x,y},f.map)]==-1) views[i].set(index({x,y}));
  }
  /// 不确定采集分支保留联合分布，先按每个分支封顶，再求期望；避免平均后封顶高估。
  struct Outcome {double added{0};int normal{0},high{0};double mass{1};};
  struct Node {
    Position at;std::uint32_t consumed{0};std::bitset<1024> revealed;
    std::vector<Outcome> outcomes{{}};std::vector<Position> path;
    double reward{0},resource{0},mission{0},info{0},effective{0},edge{0},cost{0},value{0},terminal{0};
  };
  std::vector<const MissionInfo*> missions;
  for(const auto& m:f.missions)
    if(m.target&&*m.target>0&&std::find(f.score.mission_completed_ids.begin(),
        f.score.mission_completed_ids.end(),m.id)==f.score.mission_completed_ids.end()&&
        (m.type=="normal_resources"||m.type=="high_resources"||m.type=="resource_value"))
      missions.push_back(&m);
  /// 任务只在预测达到阈值时计入机会价值，不把每一步的相同任务收益重复累加。
  const auto scores=[&](const Outcome& o) {
    const double resource=w.resource_points/w.resource_cap*
        std::max(0.0,std::min(o.added,w.resource_cap-f.score.resource_value));
    double task=0;
    for(const auto* m:missions) {
      const double before=m->type=="normal_resources"?normal_collected:
          (m->type=="high_resources"?high_collected:f.score.resource_value);
      const double after=before+(m->type=="normal_resources"?o.normal:
          (m->type=="high_resources"?o.high:o.added));
      if(before<*m->target&&after>=*m->target) task+=w.mission_points*w.mission_potential;
    }
    return std::pair<double,double>{resource,task};
  };
  const auto capture=[&](const Resource& r,int arrival) {
    return r.presence*collection_race_factor(arrival,r.enemy,f.tick,w);
  };
  /// 对尚未访问的资源求额外正式积分/任务机会，不重复估算已消耗资源。
  const auto increment=[&](const Node& n,const Resource& r) {
    double resource=0,mission=0;
    for(auto o:n.outcomes) {
      const auto before=scores(o);o.added+=r.value;o.normal+=!r.high;o.high+=r.high;
      const auto after=scores(o);
      resource+=o.mass*(after.first-before.first);mission+=o.mass*(after.second-before.second);
    }
    return std::pair<double,double>{resource,mission};
  };
  /// 当前窗口外只保留一个最有希望的后续机会；此估值不是已获得积分。
  const auto terminal=[&](const Node& n,int depth) {
    double best=0;
    for(std::size_t i=0;i<resources.size();++i) {
      if(n.consumed&(std::uint32_t{1}<<i)) continue;
      const auto& r=resources[i];const int d=r.distances[index(n.at)];
      if(d<=0||depth+d>remaining) continue;
      const auto gain=increment(n,r);
      best=std::max(best,std::pow(w.planning.discount,d)*capture(r,depth+d)*r.preference*
          (resource_weight*gain.first+mission_weight*gain.second));
    }
    if(exploration_target) {
      const int d=exploration_distances[index(n.at)];
      if(d>0&&depth+d<=remaining) {
        const auto fresh=views[index(*exploration_target)]&~n.revealed;
        double cells=n.effective,edge=n.edge;
        for(int i=0;i<count;++i)if(fresh[i]) {cells+=supplies[i];edge+=edges[i];}
        best=std::max(best,std::pow(w.planning.discount,d)*std::max(0.0,information(cells,edge)-n.info));
      }
    }
    return w.planning.terminal_weight*std::pow(w.planning.discount,depth)*best;
  };
  /// 推进一步，资源联合分布、唯一观察集合与时空风险均属于该路线自己的状态。
  const auto advance=[&](const Node& old,Position p,int depth) {
    Node n=old;n.at=p;n.path.push_back(p);
    for(std::size_t i=0;i<resources.size();++i) {
      const auto& r=resources[i];
      if((n.consumed&(std::uint32_t{1}<<i))||r.at.x!=p.x||r.at.y!=p.y)continue;
      n.consumed|=std::uint32_t{1}<<i;
      const double probability=capture(r,depth);const auto gain=increment(n,r);
      n.resource+=probability*gain.first;n.mission+=probability*gain.second;
      n.reward+=std::pow(w.planning.discount,depth-1)*probability*r.preference*
          (resource_weight*gain.first+mission_weight*gain.second);
      std::map<std::tuple<double,int,int>,double> distribution;
      for(const auto& o:n.outcomes) {
        distribution[{o.added,o.normal,o.high}]+=o.mass*(1-probability);
        distribution[{o.added+r.value,o.normal+!r.high,o.high+r.high}]+=o.mass*probability;
      }
      n.outcomes.clear();
      for(const auto& [state,mass]:distribution)if(mass>1e-12)
        n.outcomes.push_back({std::get<0>(state),std::get<1>(state),std::get<2>(state),mass});
    }
    const auto fresh=views[index(p)]&~n.revealed;n.revealed|=views[index(p)];
    for(int i=0;i<count;++i)if(fresh[i]) {n.effective+=supplies[i];n.edge+=edges[i];}
    const double info=information(n.effective,n.edge);
    n.reward+=std::pow(w.planning.discount,depth-1)*(info-n.info);n.info=info;
    if(depth>1)n.cost+=std::pow(w.planning.discount,depth-1)*w.planning.future_risk_weight*
        std::max(0.0,future_risk(p,depth));
    n.terminal=terminal(n,depth);n.value=n.reward-n.cost+n.terminal;
    return n;
  };
  std::array<std::vector<Node>,5> beams;
  Node start;start.at=f.self.position;start.path.push_back(start.at);
  /// 已经看过的出生视野不允许在WAIT预测里再获一次探索价值。
  start.revealed=views[index(start.at)];
  for(std::size_t root=0;root<deltas.size();++root) {
    const Position p{start.at.x+deltas[root].x,start.at.y+deltas[root].y};
    if(!inside(p)||(root>0&&!passable(p,1)))continue;
    beams[root].push_back(advance(start,p,1));++result.expanded;
  }
  std::optional<Node> baseline;int baseline_root=-1;
  if(original_path.size()>1&&original_path[0].x==start.at.x&&original_path[0].y==start.at.y)
    for(std::size_t root=1;root<deltas.size();++root)
      if(!beams[root].empty()&&original_path[1].x==start.at.x+deltas[root].x&&
          original_path[1].y==start.at.y+deltas[root].y) {
        baseline=beams[root].front();baseline_root=static_cast<int>(root);break;
      }
  const auto commit=[&](int depth) {
    result.useful=false;
    for(std::size_t root=0;root<beams.size();++root)if(!beams[root].empty()) {
      const auto& n=beams[root].front();auto& out=result.roots[root];out.valid=true;
      out.value=n.value;out.resource_points=n.resource;out.mission_points=n.mission;
      out.information=n.info;out.terminal=n.terminal;out.path=n.path;
      result.useful=result.useful||n.resource>0||n.mission>0||n.info>0||n.terminal>0;
    }
    result.completed_depth=depth;
  };
  commit(1);
  for(int depth=2;depth<=horizon;++depth) {
    std::array<std::vector<Node>,5> next;bool interrupted=false;
    for(std::size_t root=0;root<beams.size()&&!interrupted;++root) {
      for(const auto& n:beams[root]) {
        for(const auto delta:deltas) {
          if(result.expanded>=w.planning.max_nodes ||
              ((result.expanded&31)==0&&elapsed()>=w.planning.budget_ms)) {interrupted=true;break;}
          const Position p{n.at.x+delta.x,n.at.y+delta.y};
          if(!inside(p)||!passable(p,depth))continue;
          next[root].push_back(advance(n,p,depth));++result.expanded;
        }
        if(interrupted)break;
      }
      std::stable_sort(next[root].begin(),next[root].end(),[](const auto& a,const auto& b){return a.value>b.value;});
      // 保留不同落点/采集集合的路线，防止等价走法挤满束宽。
      std::vector<Node> unique;
      for(auto& n:next[root]) {
        if(std::any_of(unique.begin(),unique.end(),[&](const auto& old) {
          return old.at.x==n.at.x&&old.at.y==n.at.y&&old.consumed==n.consumed&&old.revealed==n.revealed;
        }))continue;
        unique.push_back(std::move(n));
        if(unique.size()>=static_cast<std::size_t>(w.planning.beam_width))break;
      }
      next[root]=std::move(unique);
    }
    if(interrupted) {result.budget_hit=true;break;}
    // 保留旧路线作为独立提案；资源到达后先等待，后续Tick再按新观察重新规划。
    std::optional<Node> next_baseline;
    if(baseline) {
      const auto p=original_path[std::min<std::size_t>(depth,original_path.size()-1)];
      if(passable(p,depth)) {
        if(result.expanded>=w.planning.max_nodes||elapsed()>=w.planning.budget_ms)
          {result.budget_hit=true;break;}
        next_baseline=advance(*baseline,p,depth);++result.expanded;
        auto& options=next[baseline_root];
        const bool retained=std::any_of(options.begin(),options.end(),[&](const auto& n) {
          return n.at.x==p.x&&n.at.y==p.y&&n.consumed==next_baseline->consumed&&
              n.revealed==next_baseline->revealed&&n.value>=next_baseline->value;
        });
        if(!retained) {
          options.push_back(*next_baseline);
          std::stable_sort(options.begin(),options.end(),[](const auto& a,const auto& b){return a.value>b.value;});
          if(options.size()>static_cast<std::size_t>(w.planning.beam_width))options.resize(w.planning.beam_width);
        }
      }
    }
    // 未来墙体可能让整组路线失效；不能拿较短窗口冒充相同深度的有效后续。
    for(std::size_t root=0;root<beams.size();++root)
      if(!beams[root].empty()&&next[root].empty()) {interrupted=true;break;}
    if(interrupted) {result.budget_hit=true;break;}
    beams=std::move(next);baseline=std::move(next_baseline);commit(depth);
  }
  return finish();
}
}  // namespace rmtc
