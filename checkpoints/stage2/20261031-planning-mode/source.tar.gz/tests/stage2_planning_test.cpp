/**
 * @file stage2_planning_test.cpp
 * @brief 验证同窗口机会成本、封顶期望、任务/观察去重、公开信息边界与预算回退。
 */
#include "rmtc_connection/stage2_strategy.hpp"
#include <cmath>
#include <chrono>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <stdexcept>

namespace {
/// Release构建仍执行的业务断言。
void require(bool value,const char* message) {if(!value)throw std::runtime_error(message);}

/// 使用完整公开视野构造基准场景，不向策略传入裁判内部状态。
rmtc::PublicPerception frame() {
  rmtc::PublicPerception f;f.session_id="planning-test";f.map={5,5};f.vision_radius=5;
  f.self.team="A";f.self.robot_id="A";f.self.position={2,2};f.self.alive=true;f.self.hp=100;
  return f;
}

/// 构造规则规定的普通资源实体。
rmtc::VisibleEntity resource(int x,int y,const char* id) {
  rmtc::VisibleEntity e;e.type="resource_normal";e.id=id;e.position={x,y};e.value=10;return e;
}

/// 仅查询本队地图记忆，隔离风险与探索权重，便于检验真实资源分的数学不变量。
rmtc::PlanningResult run(const rmtc::PublicPerception& f,const rmtc::MapMemory& memory,
                         const rmtc::Stage2Weights& w,int normal=0,bool exploration=false) {
  const auto free=[&](rmtc::Position p,int) {
    return p.x>=0&&p.x<f.map.width&&p.y>=0&&p.y<f.map.height&&
        memory.cells()[rmtc::MapMemory::index(p,f.map)]==0;
  };
  return rmtc::plan_collection_actions(f,memory,w,500,normal,0,1,1,
      std::vector<int>(25,-1),free,[&](double cells,double){return exploration?.05*cells:0.;},
      [](rmtc::Position,int){return 0.;},{});
}
} // namespace

/// 执行独立规划器与策略接线的回归，不启动ROS、裁判或外部模型。
int main(int argc,char**) {
  try {
    using namespace rmtc;
    require(std::abs(planning_damage_loss(500,500,15)-1.8)<1e-9,"500 damage loss wrong");
    require(std::abs(planning_damage_loss(540,500,15)-.6)<1e-9,"damage buffer ignored");
    require(planning_damage_loss(560,500,15)==0,"full damage buffer still loses points");
    Stage2Weights w;w.planning.enabled=true;w.planning.horizon=4;w.planning.beam_width=8;
    w.planning.max_nodes=4000;w.planning.budget_ms=100;w.planning.terminal_weight=0;
    w.planning.discount=.9;w.competition_weight=w.competition_weight_end=0;
    w.visible_resource_weight=1;
    require(planning_resource_presence(0,1,w.planning)==1,"visible resource discounted as missing");
    require(planning_resource_presence(80,-1,w.planning)>
        planning_resource_presence(80,1,w.planning),"enemy evidence did not affect existence estimate");
    auto f=frame();f.visible_entities={resource(3,2,"near")};MapMemory memory;memory.update(f);
    auto p=run(f,memory,w);
    require(p.completed_depth==4&&p.roots[0].valid&&p.roots[4].valid,"roots have unequal horizon");
    require(p.roots[4].value>p.roots[0].value,"delaying collection had no opportunity cost");
    for(const auto& r:p.roots)if(r.valid)
      require(r.resource_points<=2.5+1e-9,"one resource collected repeatedly");
    f.score.resource_value=119;p=run(f,memory,w);
    require(std::abs(p.roots[4].resource_points-.25)<1e-9,"resource score exceeded cap");
    // 旧资源存在性为0.5：必须先对每条结果封顶，不能先把10点资源均值化成5点。
    f.tick=80;f.vision_radius=0;f.visible_entities.clear();memory.update(f);
    p=run(f,memory,w);
    require(std::abs(p.roots[4].resource_points-.125)<1e-9,"uncertain reward capped after expectation");
    f.score.resource_value=120;p=run(f,memory,w);
    require(!p.useful&&p.roots[4].resource_points==0,"saturated resources created fictitious points");
    f=frame();f.visible_entities={resource(3,2,"first"),resource(4,2,"second")};
    MissionInfo m;m.id="collect-two";m.type="normal_resources";m.target=2;f.missions={m};
    memory=MapMemory{};memory.update(f);p=run(f,memory,w);
    require(std::abs(p.roots[4].mission_points-3)<1e-9,"completion opportunity missing or counted repeatedly");
    f.score.mission_completed_ids={m.id};p=run(f,memory,w);
    require(p.roots[4].mission_points==0,"completed task rewarded again");
    w.planning.max_nodes=5;p=run(f,memory,w);
    require(p.budget_hit&&p.completed_depth==1,"partial search layer committed");
    for(const auto& r:p.roots)if(r.valid)require(r.path.size()==2,"budget roots have unequal depth");
    w.planning.max_nodes=4000;
    f=frame();f.vision_radius=1;memory=MapMemory{};memory.update(f);p=run(f,memory,w,0,true);
    require(p.useful,"no-resource state failed to propose exploration");
    for(const auto& r:p.roots)if(r.valid) {
      for(const auto at:r.path)require(memory.cells()[MapMemory::index(at,f.map)]==0,
          "forecast crossed unobserved terrain");
      require(r.information<=.05*16+1e-9,"unknown observations counted repeatedly");
    }
    w.planning.enabled=false;p=run(f,memory,w);
    require(!p.ran,"disabled planner changed baseline");
    // 最后一层验证新模式已经进入真实Stage2Strategy决策和诊断入口。
    w.planning.enabled=true;w.opening_collection_ticks=40;w.collection_mode=0;
    w.frontier_resource_weight=w.frontier_mission_weight=w.information_per_cell=0;
    f=frame();f.visible_entities={resource(3,2,"right")};
    Stage2Strategy strategy(w);const auto a=strategy.decide(f);
    require(a.type=="move"&&a.direction=="right","strategy did not apply collection critic");
    require(strategy.plan().planning.value("applied",false),"new mode diagnostics missing");
    require(strategy.plan().target_id=="right","display target differs from selected collection route");
    const auto again=strategy.decide(f);
    require(a.type==again.type&&a.direction==again.direction,"duplicate Tick changed cached action");
    // 重新看到空格必须撤销旧资源，不允许新的存在性模型让已消失资源复活。
    f.tick=1;f.visible_entities.clear();f.self.position={3,2};f.score.resource_value=10;
    strategy.decide(f);
    require(strategy.plan().resource_races.empty(),"confirmed empty resource survived in planning");
    // 相同未来墙体对所有根动作使用相同时间线，首步禁止走入即将生效的墙。
    f=frame();f.visible_entities={resource(3,2,"blocked")};memory=MapMemory{};memory.update(f);
    const auto walls=[](Position p,int) {return p.x>=0&&p.x<5&&p.y>=0&&p.y<5&&!(p.x==3&&p.y==2);};
    p=plan_collection_actions(f,memory,w,500,0,0,1,1,std::vector<int>(25,-1),walls,
        [](double,double){return 0.;},[](Position,int){return 0.;},{});
    require(!p.roots[4].valid,"first move ignored dynamic wall callback");
    // 可选性能探针只执行本队公开场景，不运行比赛、不训练、不调用AI。
    if(argc>1) {
      std::vector<double> timings;int min_depth=32,max_nodes=0;
      for(int scene=0;scene<20;++scene) {
        auto probe=frame();probe.session_id="planning-benchmark";probe.map={24,24};probe.vision_radius=24;
        probe.self.position={8+scene%4,8+scene/4};probe.score.resource_value=scene%3*40;
        for(int i=0;i<16;++i)probe.visible_entities.push_back(resource(6+i%4,6+i/4,("r"+std::to_string(i)).c_str()));
        MapMemory observed;observed.update(probe);
        if(scene%2) {probe.tick=80;probe.vision_radius=0;probe.visible_entities.clear();observed.update(probe);}
        Stage2Weights params;params.planning.enabled=true;params.opening_collection_ticks=40;
        Stage2Strategy controller(params);
        // 先给策略与测试相同的完整记忆，再通过连续公开观察构造旧资源场景。
        auto initial=probe;initial.tick=0;initial.vision_radius=24;initial.visible_entities.clear();
        for(int i=0;i<16;++i)initial.visible_entities.push_back(resource(6+i%4,6+i/4,("r"+std::to_string(i)).c_str()));
        const auto began=std::chrono::steady_clock::now();
        controller.decide(initial);
        timings.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-began).count());
        if(scene%2) {
          const auto old_began=std::chrono::steady_clock::now();controller.decide(probe,420);
          timings.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-old_began).count());
        }
        const auto& detail=controller.plan().planning;
        min_depth=std::min(min_depth,detail.value("completed_depth",0));
        max_nodes=std::max(max_nodes,detail.value("expanded",0));
      }
      std::sort(timings.begin(),timings.end());
      std::cout<<Json{{"probe_decisions",timings.size()},{"decision_ms",{
          {"mean",std::accumulate(timings.begin(),timings.end(),0.0)/timings.size()},
          {"p95",timings[static_cast<std::size_t>(.95*(timings.size()-1))]},
          {"max",timings.back()}}},{"minimum_completed_depth",min_depth},{"maximum_expanded_nodes",max_nodes}}.dump()<<'\n';
    }
    std::cout<<"Planning score, uncertainty, coverage, budget and integration checks passed\n";
    return 0;
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
