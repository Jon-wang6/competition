/**
 * @file stage2_event_config.hpp
 * @brief 八类事件的独立偏好系数；事件时间、区域及实际效果数值必须来自模型解释。
 *
 * 这里只调决策收益与风险，不改裁判规则。更改后重新编译并重启；也可用同名
 * event_* ROS参数做对照。死亡上界、幻术方向与临时墙生命周期不受权重关闭。
 */
#pragma once

#include <cmath>
#include <stdexcept>

namespace rmtc {
struct Stage2EventWeights {
  double blast_risk{100.0};           ///< 爆炸/世界分裂临近生效时的空间危险代价。
  double escape_weight{0.0};          ///< 撤离距离预判权重；0关闭新增BFS，1使用完整提前风险。
  int evacuation_buffer{2};           ///< 最短撤离步数之外预留多少Tick。
  double heal_value{0.04};            ///< 每点可实际利用的回血价值，满血不凭空奖励。
  double fortress_value{4.0};         ///< 无双Buff的基础目标价值，按剩余战斗收益缩放。
  double fortress_hold{2.0};          ///< 连续驻留时保留进度的偏好，不阻止驻留期间攻击/防御。
  double pepper_cost{0.05};           ///< 辣椒开关的软成本，不封路。
  double pepper_value{0.02};          ///< 触发对敌环境伤害的战术价值，绝不计作个人伤害得分。
  double purity_defend_seen{0.8};     ///< 对手上一帧防御时，本Tick继续防御的估计概率。
  double purity_defend_other{0.2};    ///< 其他对手本Tick防御的估计概率。
  double purity_defense_value{0.02};  ///< 自己防御时潜在反伤的战术偏好。
  double vulnerability_risk{0.5};     ///< 移动新触发易伤时的未来暴露附加权重。

  /// 启动时拒绝非有限值、负收益权重及非法概率；不在比赛回调中反复检查。
  void validate() const {
    for (double v :
         {blast_risk, escape_weight, heal_value, fortress_value, fortress_hold, pepper_cost, pepper_value,
          purity_defend_seen, purity_defend_other, purity_defense_value, vulnerability_risk})
      if (!std::isfinite(v) || v < 0)
        throw std::invalid_argument("invalid event weights");
    if (blast_risk < 1 || escape_weight>2 || evacuation_buffer < 0 || evacuation_buffer > 20 ||
        purity_defend_seen > 1 || purity_defend_other > 1)
      throw std::invalid_argument("invalid event risk/probability");
  }
};
}  // namespace rmtc
